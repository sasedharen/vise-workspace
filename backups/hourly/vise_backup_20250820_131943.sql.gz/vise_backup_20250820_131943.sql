--
-- PostgreSQL database dump
--

\restrict Bj2dfF840QjpjcMZf7061JoRPbOC6pULwnHAIyHXkjzXDCdBElo94ivCqtphO5G

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-08-20 13:19:44 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 9 (class 2615 OID 16388)
-- Name: codes; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA codes;


--
-- TOC entry 3841 (class 0 OID 0)
-- Dependencies: 9
-- Name: SCHEMA codes; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA codes IS 'Reference data schema: Geographic, branch, institution, and academic codes';


--
-- TOC entry 6 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 3842 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- TOC entry 10 (class 2615 OID 16389)
-- Name: users; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA users;


--
-- TOC entry 3843 (class 0 OID 0)
-- Dependencies: 10
-- Name: SCHEMA users; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA users IS 'Users schema - cleaned up by removing legacy tables (state_codes, district_codes, academic_data, document_verification, admin_verification, workflow_tracking)';


--
-- TOC entry 291 (class 1255 OID 16439)
-- Name: validate_codes(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: codes; Owner: -
--

CREATE FUNCTION codes.validate_codes(p_state_code character varying, p_district_code character varying, p_branch_code character varying, p_institution_code character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM codes.geographic g
        JOIN codes.branch b ON (g.state_code = b.state_code AND g.district_code = b.district_code)
        JOIN codes.institution i ON (b.branch_code = i.branch_code)
        WHERE g.state_code = p_state_code 
        AND g.district_code = p_district_code
        AND b.branch_code = p_branch_code
        AND i.institution_code = p_institution_code
        AND g.is_active = true
        AND b.is_active = true
        AND i.is_active = true
    );
END;
$$;


--
-- TOC entry 292 (class 1255 OID 17735)
-- Name: update_branch_institution_unit_updated_time(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_branch_institution_unit_updated_time() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_time = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 290 (class 1255 OID 17708)
-- Name: update_unit_updated_time(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_unit_updated_time() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_time = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


--
-- TOC entry 304 (class 1255 OID 16440)
-- Name: generate_application_id(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: users; Owner: -
--

CREATE FUNCTION users.generate_application_id(p_state_code character varying, p_district_code character varying, p_branch_code character varying, p_institution_code character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_academic_year VARCHAR(2);
    v_sequence INTEGER;
    v_application_id VARCHAR(16);
BEGIN
    -- Get current academic year (last 2 digits)
    v_academic_year := RIGHT(EXTRACT(year FROM CURRENT_DATE)::text, 2);
    
    -- Get next sequence
    v_sequence := users.get_next_sequence(
        p_state_code, p_district_code, p_branch_code, p_institution_code, 
        v_academic_year, 'application'
    );
    
    -- Format: SS-DD-BB-II-YY-NNNNNN (remove hyphens for storage)
    v_application_id := p_state_code || p_district_code || p_branch_code || 
                        p_institution_code || v_academic_year || 
                        LPAD(v_sequence::text, 6, '0');
    
    RETURN v_application_id;
END;
$$;


--
-- TOC entry 305 (class 1255 OID 16441)
-- Name: generate_enrollment_id(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: users; Owner: -
--

CREATE FUNCTION users.generate_enrollment_id(p_state_code character varying, p_district_code character varying, p_branch_code character varying, p_institution_code character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_academic_year VARCHAR(2);
    v_sequence INTEGER;
    v_enrollment_id VARCHAR(16);
    v_branch_numeric VARCHAR(2);
    v_institution_numeric VARCHAR(2);
BEGIN
    -- Get current academic year (last 2 digits)
    v_academic_year := RIGHT(EXTRACT(year FROM CURRENT_DATE)::text, 2);
    
    -- Convert branch_code to numeric (remove non-numeric chars, pad with 0s)
    v_branch_numeric := LPAD(REGEXP_REPLACE(p_branch_code, '[^0-9]', '', 'g'), 2, '0');
    
    -- Institution code is already numeric
    v_institution_numeric := p_institution_code;
    
    -- Get next sequence
    v_sequence := users.get_next_sequence(
        p_state_code, p_district_code, p_branch_code, p_institution_code, 
        v_academic_year, 'enrollment'
    );
    
    -- Format: SS-DD-BB-II-YY-NNNNNN (numeric only, remove hyphens for storage)
    v_enrollment_id := p_state_code || p_district_code || v_branch_numeric || 
                       v_institution_numeric || v_academic_year || 
                       LPAD(v_sequence::text, 6, '0');
    
    RETURN v_enrollment_id;
END;
$$;


--
-- TOC entry 306 (class 1255 OID 16442)
-- Name: is_application_ready_for_next_stage(character varying); Type: FUNCTION; Schema: users; Owner: -
--

CREATE FUNCTION users.is_application_ready_for_next_stage(p_application_id character varying) RETURNS TABLE(ready boolean, current_stage character varying, next_stage character varying, blocking_issues text[])
    LANGUAGE plpgsql
    AS $$
DECLARE
    app_status VARCHAR(50);
    admin_decision VARCHAR(50);
    doc_verified_count INTEGER;
    doc_total_count INTEGER;
    doc_rejected_count INTEGER;
    result_ready BOOLEAN := FALSE;
    result_current_stage VARCHAR(100);
    result_next_stage VARCHAR(100);
    result_blocking_issues TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- Get application status
    SELECT a.status INTO app_status
    FROM users.application a 
    WHERE a.application_id = p_application_id;
    
    IF app_status IS NULL THEN
        RETURN QUERY SELECT FALSE, 'not_found'::VARCHAR(100), ''::VARCHAR(100), ARRAY['Application not found']::TEXT[];
        RETURN;
    END IF;
    
    -- Determine current stage based on application status
    CASE app_status
        WHEN 'draft' THEN
            result_current_stage := 'draft';
            result_next_stage := 'submitted';
            result_blocking_issues := ARRAY['Application must be submitted'];
            
        WHEN 'submitted' THEN
            result_current_stage := 'admin_verification';
            result_next_stage := 'document_verification';
            
            -- Check admin verification status
            SELECT av.decision INTO admin_decision
            FROM users.admin_verification av
            WHERE av.application_id = p_application_id 
                AND av.verification_type = 'initial_verification'
            ORDER BY av.verified_at DESC
            LIMIT 1;
            
            IF admin_decision = 'approved' THEN
                result_ready := TRUE;
            ELSIF admin_decision = 'rejected' THEN
                result_next_stage := 'rejected';
                result_blocking_issues := ARRAY['Application rejected by admin'];
            ELSE
                result_blocking_issues := ARRAY['Waiting for admin verification'];
            END IF;
            
        WHEN 'complete' THEN
            result_current_stage := 'document_verification';
            result_next_stage := 'enrollment_ready';
            
            -- Check document verification status
            SELECT 
                COUNT(*),
                COUNT(CASE WHEN status = 'verified' THEN 1 END),
                COUNT(CASE WHEN status = 'rejected' THEN 1 END)
            INTO doc_total_count, doc_verified_count, doc_rejected_count
            FROM users.document_verification dv
            WHERE dv.application_id = p_application_id;
            
            IF doc_total_count = 0 THEN
                result_blocking_issues := ARRAY['No documents submitted for verification'];
            ELSIF doc_rejected_count > 0 THEN
                result_blocking_issues := ARRAY['Some documents were rejected'];
            ELSIF doc_verified_count >= 2 THEN -- Expecting birth certificate and marksheet
                result_ready := TRUE;
            ELSE
                result_blocking_issues := ARRAY['Waiting for document verification completion'];
            END IF;
            
        WHEN 'rejected' THEN
            result_current_stage := 'rejected';
            result_next_stage := 'reapplication';
            result_blocking_issues := ARRAY['Application was rejected'];
            
        ELSE
            result_current_stage := app_status;
            result_next_stage := 'unknown';
            result_blocking_issues := ARRAY['Unknown application status'];
    END CASE;
    
    RETURN QUERY SELECT result_ready, result_current_stage, result_next_stage, result_blocking_issues;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 16545)
-- Name: branch; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.branch (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    branch_code character varying(2) NOT NULL,
    branch_name character varying(100) NOT NULL,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    contact_details jsonb,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    address_street character varying(255) NOT NULL,
    address_full character varying(255) NOT NULL,
    address_doorno character varying(10) NOT NULL,
    address_city character varying(50) NOT NULL,
    address_district character varying(50) NOT NULL,
    address_pincode character varying(6) NOT NULL,
    CONSTRAINT chk_branch_address_city_length CHECK ((length((address_city)::text) <= 50)),
    CONSTRAINT chk_branch_address_district_length CHECK ((length((address_district)::text) <= 50)),
    CONSTRAINT chk_branch_address_doorno_length CHECK ((length((address_doorno)::text) <= 10)),
    CONSTRAINT chk_branch_address_full_length CHECK ((length((address_full)::text) <= 255)),
    CONSTRAINT chk_branch_address_pincode_format CHECK ((((address_pincode)::text ~ '^[0-9]{6}$'::text) OR ((address_pincode)::text = ''::text))),
    CONSTRAINT chk_branch_address_street_length CHECK ((length((address_street)::text) <= 255)),
    CONSTRAINT chk_branch_code_format CHECK ((((branch_code)::text ~ '^[0-9A-Z]{2}$'::text) AND (length((branch_code)::text) = 2)))
);


--
-- TOC entry 3844 (class 0 OID 0)
-- Dependencies: 224
-- Name: TABLE branch; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON TABLE codes.branch IS 'Branch lookup table with structured address - branch_code is unique per district, allows same branch_code in different districts';


--
-- TOC entry 3845 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.branch_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.branch_code IS '2-character alphanumeric branch identifier';


--
-- TOC entry 3846 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_street; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_street IS 'Branch address street name - NOT NULL';


--
-- TOC entry 3847 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_full; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_full IS 'Branch full address - NOT NULL';


--
-- TOC entry 3848 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_doorno; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_doorno IS 'Branch address door/office number - NOT NULL';


--
-- TOC entry 3849 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_city; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_city IS 'Branch address city - NOT NULL';


--
-- TOC entry 3850 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_district; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_district IS 'Branch address district - NOT NULL';


--
-- TOC entry 3851 (class 0 OID 0)
-- Dependencies: 224
-- Name: COLUMN branch.address_pincode; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch.address_pincode IS 'Branch address pincode (6 digits) - NOT NULL';


--
-- TOC entry 225 (class 1259 OID 16561)
-- Name: branch_institution; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.branch_institution (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    branch_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 3852 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE branch_institution; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON TABLE codes.branch_institution IS 'Defines which institution types each branch offers - School at both branches, Music at Thanjavur, Engineering at Tiruchirappalli';


--
-- TOC entry 3853 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN branch_institution.state_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch_institution.state_code IS 'State code from branch';


--
-- TOC entry 3854 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN branch_institution.district_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch_institution.district_code IS 'District code from branch';


--
-- TOC entry 3855 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN branch_institution.branch_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch_institution.branch_code IS 'Branch code (unique per district)';


--
-- TOC entry 3856 (class 0 OID 0)
-- Dependencies: 225
-- Name: COLUMN branch_institution.institution_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.branch_institution.institution_code IS 'Institution type code (School, Engineering, etc.)';


--
-- TOC entry 240 (class 1259 OID 17710)
-- Name: branch_institution_unit; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.branch_institution_unit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    branch_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    unit_code character varying(3) NOT NULL,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 239 (class 1259 OID 17687)
-- Name: unit; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.unit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    institution_code character varying(2) NOT NULL,
    unit_code character varying(3) NOT NULL,
    unit_name character varying(100) NOT NULL,
    unit_type character varying(50),
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_unit_code_format CHECK ((((unit_code)::text ~ '^[A-Z]{3}$'::text) AND (char_length((unit_code)::text) = 3)))
);


--
-- TOC entry 241 (class 1259 OID 17757)
-- Name: branch_institution_unit_details; Type: VIEW; Schema: codes; Owner: -
--

CREATE VIEW codes.branch_institution_unit_details AS
 SELECT biu.id,
    biu.state_code,
    biu.district_code,
    biu.branch_code,
    biu.institution_code,
    biu.unit_code,
    u.unit_name,
    u.unit_type,
    biu.is_active,
    biu.created_time,
    biu.updated_time
   FROM (codes.branch_institution_unit biu
     JOIN codes.unit u ON ((((biu.institution_code)::text = (u.institution_code)::text) AND ((biu.unit_code)::text = (u.unit_code)::text))));


--
-- TOC entry 226 (class 1259 OID 16568)
-- Name: curriculum; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.curriculum (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    program_code character varying(3) NOT NULL,
    program_name character varying(100) NOT NULL,
    department_code character varying(3) NOT NULL,
    department_name character varying(100) NOT NULL,
    institution_code character varying(2) NOT NULL,
    academic_level character varying(20),
    capacity integer,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_academic_level CHECK (((academic_level)::text = ANY (ARRAY[('Primary'::character varying)::text, ('Secondary'::character varying)::text, ('Higher Secondary'::character varying)::text, ('Undergraduate'::character varying)::text, ('Graduate'::character varying)::text, ('Postgraduate'::character varying)::text]))),
    CONSTRAINT chk_capacity CHECK (((capacity IS NULL) OR (capacity > 0))),
    CONSTRAINT chk_department_code_format CHECK ((((department_code)::text ~ '^[0-9A-Z]{3}$'::text) AND (length((department_code)::text) = 3))),
    CONSTRAINT chk_program_code_format CHECK ((((program_code)::text ~ '^[0-9A-Z]{3}$'::text) AND (length((program_code)::text) = 3)))
);


--
-- TOC entry 3857 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE curriculum; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON TABLE codes.curriculum IS 'Optimized curriculum lookup - program_code contains class info (PKG, S01, BTH, etc.), no class_code duplication';


--
-- TOC entry 3858 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN curriculum.program_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.curriculum.program_code IS '3-char program code: PKG/LKG/S01-S12 (school), BTH/MED/etc (higher ed)';


--
-- TOC entry 3859 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN curriculum.program_name; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.curriculum.program_name IS 'Full program name (was class_name for school, program_name for others)';


--
-- TOC entry 3860 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN curriculum.institution_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.curriculum.institution_code IS 'Institution type code (00=School, 01=Polytechnic, etc.)';


--
-- TOC entry 3861 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN curriculum.academic_level; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.curriculum.academic_level IS 'Educational level: Primary, Secondary, Undergraduate, etc.';


--
-- TOC entry 227 (class 1259 OID 16579)
-- Name: geographic; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.geographic (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    state_code character varying(2) NOT NULL,
    state_name character varying(100) NOT NULL,
    district_code character varying(2) NOT NULL,
    district_name character varying(100) NOT NULL,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_district_code_format CHECK ((((district_code)::text ~ '^[0-9]{2}$'::text) AND (length((district_code)::text) = 2))),
    CONSTRAINT chk_state_code_format CHECK ((((state_code)::text ~ '^[0-9]{2}$'::text) AND (length((state_code)::text) = 2)))
);


--
-- TOC entry 3862 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE geographic; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON TABLE codes.geographic IS 'Geographic lookup table: South Indian states (TN-33, KA-29, KL-32, AP-28, TG-36) with all districts as per government data';


--
-- TOC entry 3863 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN geographic.state_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.geographic.state_code IS '2-digit numeric state code as per government standards';


--
-- TOC entry 3864 (class 0 OID 0)
-- Dependencies: 227
-- Name: COLUMN geographic.district_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.geographic.district_code IS '2-digit numeric district code as per government standards';


--
-- TOC entry 228 (class 1259 OID 16587)
-- Name: institution; Type: TABLE; Schema: codes; Owner: -
--

CREATE TABLE codes.institution (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    institution_code character varying(2) NOT NULL,
    institution_name character varying(100) NOT NULL,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_institution_code_format CHECK ((((institution_code)::text ~ '^[0-9]{2}$'::text) AND (length((institution_code)::text) = 2)))
);


--
-- TOC entry 3865 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE institution; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON TABLE codes.institution IS 'Institution type lookup table (simplified - removed branch_code dependency and other columns)';


--
-- TOC entry 3866 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN institution.institution_code; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.institution.institution_code IS '2-digit institution type code (00-10)';


--
-- TOC entry 3867 (class 0 OID 0)
-- Dependencies: 228
-- Name: COLUMN institution.institution_name; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON COLUMN codes.institution.institution_name IS 'Institution type name (School, Engineering, etc.)';


--
-- TOC entry 229 (class 1259 OID 16594)
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 16600)
-- Name: academic; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.academic (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    program_code character varying(3) NOT NULL,
    department_code character varying(3) NOT NULL,
    entrance_score numeric,
    ai_score numeric,
    last_institution jsonb,
    academic_records jsonb,
    document_records jsonb,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    institution_code character varying(2) NOT NULL,
    CONSTRAINT chk_academic_ai_score CHECK (((ai_score IS NULL) OR ((ai_score >= (0)::numeric) AND (ai_score <= (100)::numeric)))),
    CONSTRAINT chk_academic_entrance_score CHECK (((entrance_score IS NULL) OR ((entrance_score >= (0)::numeric) AND (entrance_score <= (100)::numeric))))
);


--
-- TOC entry 3868 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE academic; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.academic IS 'Student academic records - now properly linked to branch-specific curriculum system';


--
-- TOC entry 231 (class 1259 OID 16610)
-- Name: application; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.application (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16),
    application_status text DEFAULT 'draft'::text,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    branch_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    academic_year character varying(9) DEFAULT (((EXTRACT(year FROM CURRENT_DATE))::text || '-'::text) || ((EXTRACT(year FROM CURRENT_DATE) + (1)::numeric))::text),
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    submitted_time timestamp without time zone,
    reviewed_time timestamp without time zone,
    reviewer_name text,
    draft_expires_time timestamp without time zone,
    last_expiry_check_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expiry_processed boolean DEFAULT false,
    offer_issued_time timestamp without time zone,
    offer_response_time timestamp without time zone,
    fees_paid_time timestamp without time zone,
    enrolled_time timestamp without time zone,
    CONSTRAINT chk_application_status_values CHECK ((application_status = ANY (ARRAY['draft'::text, 'submitted'::text, 'pending'::text, 'review'::text, 'accepted'::text, 'offer'::text, 'fees'::text, 'withdrawn'::text, 'enrolled'::text, 'rejected'::text, 'expired'::text, 'offer_rejected'::text]))),
    CONSTRAINT chk_enrollment_id_format CHECK (((enrollment_id IS NULL) OR ((length((enrollment_id)::text) = 16) AND ((enrollment_id)::text ~ '^[0-9]{16}$'::text))))
);


--
-- TOC entry 3869 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE application; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.application IS 'Application table now uses only enrollment_id (numeric) for identification and tracking throughout the entire lifecycle from draft to enrollment';


--
-- TOC entry 3870 (class 0 OID 0)
-- Dependencies: 231
-- Name: COLUMN application.enrollment_id; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.application.enrollment_id IS '16-digit enrollment ID: SS-DD-BB-II-YY-NNNNNN (numeric only)';


--
-- TOC entry 232 (class 1259 OID 16624)
-- Name: document; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.document (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    doc_type text NOT NULL,
    name text,
    url text,
    created_time timestamp without time zone DEFAULT now(),
    updated_time timestamp without time zone DEFAULT now(),
    enrollment_id character varying(16)
);


--
-- TOC entry 233 (class 1259 OID 16632)
-- Name: document_verification; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.document_verification (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    document_type character varying(100) NOT NULL,
    admin_id character varying(255) NOT NULL,
    admin_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    comments text,
    verified_time timestamp without time zone DEFAULT now() NOT NULL,
    created_time timestamp without time zone DEFAULT now() NOT NULL,
    updated_time timestamp without time zone DEFAULT now() NOT NULL,
    enrollment_id character varying(16)
);


--
-- TOC entry 234 (class 1259 OID 16641)
-- Name: parent; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.parent (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    parent_type character varying(50) NOT NULL,
    name character varying(50) NOT NULL,
    qualification character varying(50),
    profession character varying(50),
    annual_earnings numeric,
    pan_card character varying(10),
    contact_number character varying(15),
    email character varying(50),
    alternate_number character varying(15),
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_parent_contact_format CHECK (((contact_number IS NULL) OR ((contact_number)::text ~ '^[0-9]{10,15}$'::text))),
    CONSTRAINT chk_parent_earnings CHECK (((annual_earnings IS NULL) OR (annual_earnings >= (0)::numeric))),
    CONSTRAINT chk_parent_pan_format CHECK (((pan_card IS NULL) OR (((pan_card)::text ~ '^[A-Z]{5}[0-9]{4}[A-Z]{1}$'::text) AND (length((pan_card)::text) = 10)))),
    CONSTRAINT chk_parent_type CHECK (((parent_type)::text = ANY (ARRAY['father'::text, 'mother'::text, 'guardian'::text, 'other'::text, 'Father'::text, 'Mother'::text, 'Guardian'::text, 'Other'::text])))
);


--
-- TOC entry 3871 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE parent; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.parent IS 'Parent/guardian information linked to student enrollment';


--
-- TOC entry 3872 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN parent.parent_type; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.parent.parent_type IS 'Relationship: Father, Mother, Guardian, Other';


--
-- TOC entry 235 (class 1259 OID 16653)
-- Name: sibling; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.sibling (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    name character varying(255) NOT NULL,
    age character varying(10),
    gender character varying(50),
    school character varying(255),
    class character varying(50),
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_sibling_gender CHECK (((gender IS NULL) OR ((gender)::text = ANY (ARRAY[('Male'::character varying)::text, ('Female'::character varying)::text, ('Other'::character varying)::text]))))
);


--
-- TOC entry 3873 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE sibling; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.sibling IS 'Sibling information for enrolled students';


--
-- TOC entry 236 (class 1259 OID 16662)
-- Name: skill; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.skill (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    skill_name character varying(50) NOT NULL,
    skill_category character varying(30),
    proficiency_level character varying(20),
    certification_details jsonb,
    acquired_date date,
    last_updated_date date,
    branch_code character varying(2) NOT NULL,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    CONSTRAINT chk_skill_district_code_format CHECK (((district_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_skill_institution_code_format CHECK (((institution_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_skill_state_code_format CHECK (((state_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_skills_category CHECK (((skill_category IS NULL) OR ((skill_category)::text = ANY (ARRAY[('Technical'::character varying)::text, ('Creative'::character varying)::text, ('Leadership'::character varying)::text, ('Language'::character varying)::text, ('Communication'::character varying)::text, ('Analytical'::character varying)::text, ('Physical'::character varying)::text, ('Social'::character varying)::text])))),
    CONSTRAINT chk_skills_dates CHECK (((acquired_date IS NULL) OR (last_updated_date IS NULL) OR (last_updated_date >= acquired_date))),
    CONSTRAINT chk_skills_proficiency CHECK (((proficiency_level IS NULL) OR ((proficiency_level)::text = ANY (ARRAY[('Basic'::character varying)::text, ('Intermediate'::character varying)::text, ('Advanced'::character varying)::text, ('Expert'::character varying)::text, ('Master'::character varying)::text]))))
);


--
-- TOC entry 3874 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE skill; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.skill IS 'Student skills and certifications (renamed from skills for singular consistency)';


--
-- TOC entry 3875 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN skill.certification_details; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.skill.certification_details IS 'JSON object with certificate info, issuer, validity, etc.';


--
-- TOC entry 237 (class 1259 OID 16677)
-- Name: sport; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.sport (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    sport_name character varying(50) NOT NULL,
    sport_category character varying(30),
    skill_level character varying(20),
    participation_year character varying(4),
    achievements jsonb,
    coach_name character varying(100),
    training_hours_per_week integer,
    branch_code character varying(2) NOT NULL,
    is_active boolean DEFAULT true,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    CONSTRAINT chk_sport_district_code_format CHECK (((district_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_sport_institution_code_format CHECK (((institution_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_sport_state_code_format CHECK (((state_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_sports_category CHECK (((sport_category IS NULL) OR ((sport_category)::text = ANY (ARRAY[('Individual'::character varying)::text, ('Team'::character varying)::text, ('Indoor'::character varying)::text, ('Outdoor'::character varying)::text, ('Water'::character varying)::text, ('Combat'::character varying)::text, ('Racquet'::character varying)::text])))),
    CONSTRAINT chk_sports_skill_level CHECK (((skill_level IS NULL) OR ((skill_level)::text = ANY (ARRAY[('Beginner'::character varying)::text, ('Intermediate'::character varying)::text, ('Advanced'::character varying)::text, ('Expert'::character varying)::text, ('Professional'::character varying)::text])))),
    CONSTRAINT chk_sports_training_hours CHECK (((training_hours_per_week IS NULL) OR ((training_hours_per_week >= 0) AND (training_hours_per_week <= 168)))),
    CONSTRAINT chk_sports_year_format CHECK (((participation_year IS NULL) OR (((participation_year)::text ~ '^[0-9]{4}$'::text) AND (length((participation_year)::text) = 4))))
);


--
-- TOC entry 3876 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE sport; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.sport IS 'Student sports participation (renamed from sports for singular consistency)';


--
-- TOC entry 3877 (class 0 OID 0)
-- Dependencies: 237
-- Name: COLUMN sport.achievements; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.sport.achievements IS 'JSON array of awards, tournaments, rankings, etc.';


--
-- TOC entry 238 (class 1259 OID 16693)
-- Name: student; Type: TABLE; Schema: users; Owner: -
--

CREATE TABLE users.student (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enrollment_id character varying(16) NOT NULL,
    roll_no character varying(10) NOT NULL,
    first_name character varying(50) NOT NULL,
    middle_name character varying(50),
    surname character varying(50) NOT NULL,
    date_of_birth character varying(50) NOT NULL,
    gender character varying(50) NOT NULL,
    blood_group character varying(10),
    mother_tongue character varying(25),
    nationality character varying(25),
    religion character varying(25),
    category character varying(10),
    email character varying(50) NOT NULL,
    aadhaar_id character varying(12) NOT NULL,
    apaar_id character varying(12) NOT NULL,
    primary_mobile character varying(20) NOT NULL,
    alternative_mobile character varying(20),
    landline_number character varying(15),
    alternate_landline_number character varying(15),
    permanent_address jsonb,
    branch_code character varying(2) NOT NULL,
    academic_year character varying(9) DEFAULT (((EXTRACT(year FROM CURRENT_DATE))::text || '-'::text) || ((EXTRACT(year FROM CURRENT_DATE) + (1)::numeric))::text) NOT NULL,
    created_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    state_code character varying(2) NOT NULL,
    district_code character varying(2) NOT NULL,
    institution_code character varying(2) NOT NULL,
    communication_street character varying(255) NOT NULL,
    communication_address character varying(255) NOT NULL,
    communication_doorno character varying(10) NOT NULL,
    communication_city character varying(50) NOT NULL,
    communication_district character varying(50) NOT NULL,
    communication_pincode character varying(6) NOT NULL,
    emis_no character varying(10),
    CONSTRAINT chk_student_aadhaar_format CHECK ((((aadhaar_id)::text ~ '^[0-9]{12}$'::text) AND (length((aadhaar_id)::text) = 12))),
    CONSTRAINT chk_student_academic_year_format CHECK ((((academic_year)::text ~ '^[0-9]{4}-[0-9]{2}$'::text) AND (length((academic_year)::text) = 7))),
    CONSTRAINT chk_student_apaar_format CHECK ((((apaar_id)::text ~ '^[0-9A-Z]{12}$'::text) AND (length((apaar_id)::text) = 12))),
    CONSTRAINT chk_student_communication_address_length CHECK ((length((communication_address)::text) <= 255)),
    CONSTRAINT chk_student_communication_city_length CHECK ((length((communication_city)::text) <= 50)),
    CONSTRAINT chk_student_communication_district_length CHECK ((length((communication_district)::text) <= 50)),
    CONSTRAINT chk_student_communication_doorno_length CHECK ((length((communication_doorno)::text) <= 10)),
    CONSTRAINT chk_student_communication_pincode_format CHECK ((((communication_pincode)::text ~ '^[0-9]{6}$'::text) OR ((communication_pincode)::text = ''::text))),
    CONSTRAINT chk_student_communication_street_length CHECK ((length((communication_street)::text) <= 255)),
    CONSTRAINT chk_student_district_code_format CHECK (((district_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_student_emis_format CHECK (((emis_no IS NULL) OR (((emis_no)::text ~ '^[0-9]{10}$'::text) AND (length((emis_no)::text) = 10)))),
    CONSTRAINT chk_student_gender CHECK (((gender)::text = ANY (ARRAY[('Male'::character varying)::text, ('Female'::character varying)::text, ('Other'::character varying)::text]))),
    CONSTRAINT chk_student_institution_code_format CHECK (((institution_code)::text ~ '^[0-9]{2}$'::text)),
    CONSTRAINT chk_student_mobile_format CHECK (((primary_mobile)::text ~ '^[0-9]{10,15}$'::text)),
    CONSTRAINT chk_student_state_code_format CHECK (((state_code)::text ~ '^[0-9]{2}$'::text))
);


--
-- TOC entry 3878 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE student; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON TABLE users.student IS 'Student records with roll number for class-based sorting';


--
-- TOC entry 3879 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.enrollment_id; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.enrollment_id IS 'Links to application table enrollment_id';


--
-- TOC entry 3880 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.roll_no; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.roll_no IS 'Class-based roll number for sorting students alphabetically';


--
-- TOC entry 3881 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.permanent_address; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.permanent_address IS 'Permanent address as JSONB - kept intact';


--
-- TOC entry 3882 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.academic_year; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.academic_year IS 'Academic year in YYYY-YY format (e.g., 2025-26) - NOT NULL';


--
-- TOC entry 3883 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.state_code; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.state_code IS '2-digit numeric state code for geographic hierarchy';


--
-- TOC entry 3884 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.district_code; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.district_code IS '2-digit numeric district code for geographic hierarchy';


--
-- TOC entry 3885 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.institution_code; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.institution_code IS '2-digit numeric institution code for local hierarchy';


--
-- TOC entry 3886 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_street; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_street IS 'Communication address street name - NOT NULL';


--
-- TOC entry 3887 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_address; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_address IS 'Communication address full address - NOT NULL';


--
-- TOC entry 3888 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_doorno; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_doorno IS 'Communication address door/house number - NOT NULL';


--
-- TOC entry 3889 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_city; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_city IS 'Communication address city - NOT NULL';


--
-- TOC entry 3890 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_district; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_district IS 'Communication address district - NOT NULL';


--
-- TOC entry 3891 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN student.communication_pincode; Type: COMMENT; Schema: users; Owner: -
--

COMMENT ON COLUMN users.student.communication_pincode IS 'Communication address pincode (6 digits) - NOT NULL';


--
-- TOC entry 3819 (class 0 OID 16545)
-- Dependencies: 224
-- Data for Name: branch; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.branch (id, branch_code, branch_name, state_code, district_code, contact_details, is_active, created_time, updated_time, address_street, address_full, address_doorno, address_city, address_district, address_pincode) FROM stdin;
428a97cc-e7c8-4c54-8c8e-ae45092a1f10	01	Main Campus Mumbai	14	01	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Bandra West, Mumbai				
76f23a6f-2899-4dbe-b97f-d97d1fc88b01	02	Andheri Branch	14	02	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Andheri East, Mumbai				
4af33d53-a5b7-4937-931b-4483929a86d6	03	Pune Main Campus	14	03	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Koregaon Park, Pune				
76622c74-f156-4586-8399-0dd15d507d66	04	Nashik Branch	14	04	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		College Road, Nashik				
c48f2627-6be2-478e-9bbc-1782181f5526	05	Central Delhi Campus	07	01	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Connaught Place, New Delhi				
4303c47f-fc0a-442a-80eb-3a3b32047986	06	South Delhi Branch	07	02	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Greater Kailash, New Delhi				
a1744021-0438-4ba3-99e6-658e01f15216	07	Bangalore Main	29	01	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Koramangala, Bangalore				
5883a7f6-ab06-4cd8-a205-22e51267cbc3	08	Mysore Branch	29	03	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		Saraswathipuram, Mysore				
26bde336-8e6a-4e51-b445-08e0dc75f5e1	09	Chennai Central	33	01	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		T. Nagar, Chennai				
fe2881c1-ba37-4022-b7c5-05ae94a0189c	10	Coimbatore Campus	33	02	\N	t	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193		RS Puram, Coimbatore				
20330613-b15b-4978-bb52-9b3adfd2fa05	11	Thanjavur Main Campus	33	26	\N	t	2025-08-14 07:02:02.071757	2025-08-14 07:02:02.071757	Trichy Main Road	Adaikalamatha College Campus, Arun Nagar, Trichy Main Road, Vallam	Adaikala	Thanjavur	Thanjavur	613403
260f0a01-b884-48e3-a3ff-bdff45cd2c84	12	Tiruchirappalli E.B Colony Campus	33	29	\N	t	2025-08-14 07:02:02.071757	2025-08-14 07:02:02.071757	EB Colony Main Road	EB Colony Main Rd, E.B.Colony, Kajamalai Colony, Edamalaipatti Pudur	EB Colony	Tiruchirappalli	Tiruchirappalli	620023
\.


--
-- TOC entry 3820 (class 0 OID 16561)
-- Dependencies: 225
-- Data for Name: branch_institution; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.branch_institution (id, state_code, district_code, branch_code, institution_code, is_active, created_time, updated_time) FROM stdin;
98eade75-0873-4efa-b51f-b7a807b9c305	33	26	11	00	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
570fd748-d2ad-4d0a-a075-2324adedc6c3	33	29	12	00	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
e6eae8d2-9c17-4256-82e4-42254c31875c	33	26	11	10	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
bce42066-9106-4a71-ad2e-3bce10a1ecdc	33	29	12	04	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
\.


--
-- TOC entry 3835 (class 0 OID 17710)
-- Dependencies: 240
-- Data for Name: branch_institution_unit; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.branch_institution_unit (id, state_code, district_code, branch_code, institution_code, unit_code, is_active, created_time, updated_time) FROM stdin;
79b99502-5293-4248-a373-a56073bf47c6	33	26	11	00	ACD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
dea83fe3-2982-4e68-96c9-cbaa62a232ad	33	26	11	00	LIB	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
50539ab9-5cab-4079-a5ba-e61198d092f3	33	26	11	00	SPT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
cfb5d35a-a727-4252-bb23-2f48ec4734dc	33	26	11	00	ADM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
1f65b29f-ffce-4b35-94e4-61059de91fac	33	26	11	00	ADT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
056c92b4-7b08-418f-82e4-5fa9b9aca477	33	26	11	00	FIN	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
cccf3748-5a57-43bc-9aba-aad7f3a7edc5	33	26	11	00	HRD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
5b792a11-653d-48c0-ba2e-1e13eea622ac	33	26	11	00	ICT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
0db544f8-8317-4ddd-b2e5-0b4c3a55f2f8	33	26	11	00	OPS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
ebb9b8f8-4f17-4d3c-9424-98bb0a1737d4	33	26	11	00	MKT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
9371fecd-f62d-49b7-a73d-a2b18a02c303	33	26	11	00	COM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
9cedc67b-4592-4cf4-9f26-b5276ad16115	33	26	11	00	PRM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
6da80fdb-4301-4fc1-a54e-ee844bf8e3bc	33	26	11	00	CRM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
6cdf3c37-23a2-47d8-96db-0ca8a28cf812	33	26	11	00	LOG	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
9918fe98-d67b-41ea-ad5b-64c1d930696c	33	26	11	00	FOD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
362afd94-7c38-49c4-b87e-538830be4377	33	26	11	00	HWS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
6e6f4ec3-2323-4de4-a876-2bbb5bf4c85c	33	26	11	00	TSP	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
74120578-69bc-494f-bf4d-3ab23db34421	33	26	11	00	LBS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
78a1b93d-7ef4-45dd-9e98-bc6f116df24b	33	29	12	00	ACD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
778f0c84-e6a7-493d-b487-4f1478923a25	33	29	12	00	LIB	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
61b4080e-6175-4e33-9c07-c9f9d6c39efb	33	29	12	00	SPT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
5f49175d-dab5-4465-a0c8-5f394df529d3	33	29	12	00	ADM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
6de2f052-f75f-48da-8156-fec04adc1952	33	29	12	00	ADT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
22e7f68c-2caa-44b1-968e-ba2842e86b56	33	29	12	00	FIN	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
ff0f88b0-26d7-4772-8843-6ab49bfa89cc	33	29	12	00	HRD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
31024f92-2b39-474d-9c44-3089e535447f	33	29	12	00	ICT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
fcc9395e-98f4-424e-8950-407c9bade308	33	29	12	00	OPS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
a6e216a9-0053-46e0-985d-8bfaf3c82ebf	33	29	12	00	MKT	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
49b13255-8d05-4bfb-a1df-f0bd98b1be99	33	29	12	00	COM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
36b8a2d4-1388-43b1-a59b-e6e8efb7d248	33	29	12	00	PRM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
52c84078-902f-439f-938c-1158b5b19ae5	33	29	12	00	CRM	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
f8021a86-9168-4ceb-873b-32d5c705fc7b	33	29	12	00	LOG	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
1acaa34c-ee7c-4ff3-adaf-c5bfb062b1d2	33	29	12	00	FOD	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
a02b7c73-cb15-4ad1-9d6b-e939340dc661	33	29	12	00	HWS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
f11d09a2-793c-4ed5-9692-6b511c387174	33	29	12	00	TSP	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
465c052a-9f42-4b57-99d1-1500a1c6637b	33	29	12	00	LBS	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
\.


--
-- TOC entry 3821 (class 0 OID 16568)
-- Dependencies: 226
-- Data for Name: curriculum; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.curriculum (id, program_code, program_name, department_code, department_name, institution_code, academic_level, capacity, is_active, created_time, updated_time) FROM stdin;
18113059-b822-427a-927e-c76f4e57e98a	LKG	Lower Kindergarten	KID	Early Years Education	00	Primary	30	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
3b2c66cc-f4b1-4c90-bedf-f11911d45fc9	PKG	Pre-Kindergarten	KID	Early Years Education	00	Primary	30	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
93536585-bcfd-45da-a3b8-d339f0ac9719	UKG	Upper Kindergarten	KID	Early Years Education	00	Primary	30	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
68a3223b-17ff-45dc-a717-7c2eed87b16b	S11	Class 11	HSC	Higher Secondary Education	00	Higher Secondary	45	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
4f5b9b5e-7949-4129-bc73-0d3df9f5933a	S12	Class 12	HSC	Higher Secondary Education	00	Higher Secondary	45	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
313728c3-3abb-4398-8a11-d6d6420e9931	S01	Class 1	PRI	Primary Education	00	Primary	35	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
c0664483-7d1c-4db2-b08a-41194a6a20b7	S02	Class 2	PRI	Primary Education	00	Primary	35	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
8a547a81-3acc-4a04-b1a3-b761b45e1be8	S03	Class 3	PRI	Primary Education	00	Primary	35	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
f95a7686-6e1f-468d-a811-0417d0046b5b	S04	Class 4	PRI	Primary Education	00	Primary	35	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
5a9552ea-cbd2-4051-9886-45bfdff1ac8f	S05	Class 5	PRI	Primary Education	00	Primary	35	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
3ff87d48-de1e-4808-94d4-d0cfef7e60e5	S06	Class 6	SEC	Secondary Education	00	Secondary	40	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
56b08f6e-e55c-4b36-893b-1640d3cd9093	S07	Class 7	SEC	Secondary Education	00	Secondary	40	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
d88546c2-26f4-4561-ad63-8d4b0056a113	S08	Class 8	SEC	Secondary Education	00	Secondary	40	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
6ea2bc7c-47ba-40d1-bb09-d3b4dc8b9e7c	S09	Class 9	SEC	Secondary Education	00	Secondary	40	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
1706f8f0-0484-44d7-a7c8-c74b5d511977	S10	Class 10	SEC	Secondary Education	00	Secondary	40	t	2025-08-14 07:02:02.199488	2025-08-14 07:02:02.199488
665a92d7-c7e9-48c6-803b-0cbdb318320b	DME	Diploma in Mechanical Engineering	ENG	Engineering	01	Undergraduate	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
9f19ea2b-50fa-4a73-b99e-cf36853d123d	DEE	Diploma in Electrical Engineering	ENG	Engineering	01	Undergraduate	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
207b8760-e79d-4e7b-80c1-d4eeb3bbf228	DCE	Diploma in Civil Engineering	ENG	Engineering	01	Undergraduate	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
5f439013-2710-4b1f-bf46-68ad32e1142f	DCS	Diploma in Computer Science	CSE	Computer Science	01	Undergraduate	35	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
3d42404f-fed2-4dd2-97ac-6edefa4c27f9	DEC	Diploma in Electronics & Communication	ECE	Electronics	01	Undergraduate	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
c25e03e7-3879-4d4f-9b26-b50c573f2f04	WLD	Welding Technology	TRD	Trades	02	Primary	25	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
9b168db2-65fa-4a79-bd0b-b1c9fa031594	ELC	Electrician	TRD	Trades	02	Primary	25	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
1592292c-f14b-4f02-8101-7008ff2104d9	FTR	Fitter	TRD	Trades	02	Primary	25	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
d2407efc-fbe0-42e5-8fd1-2fec36527d6b	TUR	Turner	TRD	Trades	02	Primary	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
956ce174-b004-4236-8461-382e4c207d1c	PLM	Plumbing	TRD	Trades	02	Primary	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
791019c9-3dd6-4157-9926-ea5095a9db87	BSP	Bachelor of Science - Physics	SCI	Science	03	Undergraduate	40	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
64595b5f-622f-4b9f-be55-b3a5f108101e	BSC	Bachelor of Science - Chemistry	SCI	Science	03	Undergraduate	40	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
d5e97e75-d855-4e87-ba45-913d3cb5e56b	BSM	Bachelor of Science - Mathematics	SCI	Science	03	Undergraduate	40	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
aeeed1fa-1659-4c0a-a14d-34f4dfbea23c	MSP	Master of Science - Physics	SCI	Science	03	Postgraduate	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
1ce31f06-d06a-4178-a794-98f05ec3dfe0	MSC	Master of Science - Chemistry	SCI	Science	03	Postgraduate	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
5dc7f8d2-ac64-4f18-9aa7-13b1351081ba	BAE	Bachelor of Arts - English	ART	Arts	03	Undergraduate	45	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
1001fcce-f37a-4b4e-bf1d-284a1c055633	BAH	Bachelor of Arts - History	ART	Arts	03	Undergraduate	35	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
8214a57a-4e6f-4df6-bb4c-a5494bc1dfdc	MBB	Bachelor of Medicine (MBBS)	MED	Medicine	06	Undergraduate	100	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
a823965e-0e4a-43b7-9b82-69dbc0a37743	BDS	Bachelor of Dental Surgery	DEN	Dentistry	06	Undergraduate	50	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
d461a015-d906-4a4e-9cc7-e3b1d393397f	BSN	Bachelor of Science - Nursing	NUR	Nursing	06	Undergraduate	60	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
3364cfe0-92e4-41c8-9fee-8caf7516f10c	BPH	Bachelor of Pharmacy	PHR	Pharmacy	06	Undergraduate	60	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
31ee18cb-c43b-44d5-a782-2f947a42c6b1	MSR	Master of Surgery	MED	Medicine	06	Postgraduate	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
e740a1ef-db08-4ca3-8fec-479d95dd1abf	CRK	Cricket Training	SPT	Sports	09	Primary	25	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
451ff252-972e-4d1f-8141-a3bc5f16d4a1	FTB	Football Training	SPT	Sports	09	Primary	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
fb8f4abc-1032-492b-8ee5-2451f47ab52e	ATH	Athletics Training	SPT	Sports	09	Primary	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
7416dc62-3579-452b-9bb5-97ce803a7c81	SWM	Swimming Training	SPT	Sports	09	Primary	15	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
e1415f33-0137-49e3-b458-0c9d427b7546	TEN	Tennis Training	SPT	Sports	09	Primary	12	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
66c6799d-e4e4-41dd-97f3-08023aa93c0e	BAR	Bachelor of Architecture	ARC	Architecture	05	Undergraduate	40	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
97cce5ee-757a-41e4-b925-913feb4c2fc5	MAR	Master of Architecture	ARC	Architecture	05	Postgraduate	20	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
3d274252-d5c5-4181-ba57-b49353029e1f	DID	Diploma in Interior Design	INT	Interior Design	05	Undergraduate	30	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
d54d5e36-3b7b-472f-9d80-9d5915ee2699	PHD	Doctor of Philosophy	RES	Research	07	Graduate	15	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
d2ed6ff9-20c2-4d54-baae-c8319cca4188	MPH	Master of Philosophy	RES	Research	07	Postgraduate	10	t	2025-08-14 07:02:02.24696	2025-08-14 07:02:02.24696
\.


--
-- TOC entry 3822 (class 0 OID 16579)
-- Dependencies: 227
-- Data for Name: geographic; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.geographic (id, state_code, state_name, district_code, district_name, created_time, updated_time) FROM stdin;
14f03b1b-0460-48aa-b1da-94e98868732c	14	Maharashtra	01	Mumbai	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
727568ba-adaf-486e-b908-2ef8aee19d51	14	Maharashtra	02	Mumbai Suburban	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
60792b8c-3a26-4469-b0c8-a3f81b694085	14	Maharashtra	03	Pune	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
fcb266bd-a867-4fae-a858-0d85c5edc9d1	14	Maharashtra	04	Nashik	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
47961f8a-c2fe-4e12-a0ab-3e0645ead3d3	14	Maharashtra	05	Nagpur	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
f95c5842-1afe-4e1e-8cd7-a81ed705b2be	07	Delhi	01	Central Delhi	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
81de8eb8-b92a-4878-9022-bb0a9fe72818	07	Delhi	02	South Delhi	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
df5d1d3e-3d94-4f72-ad02-fc5abfd9e86c	07	Delhi	03	North Delhi	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
1fc44c96-33fe-4724-9fa7-b07acee29b10	07	Delhi	04	East Delhi	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
3a2f134c-735f-47c4-a3af-53ced1f47f7d	07	Delhi	05	West Delhi	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
af70b45a-4c4f-40f5-a472-9c6e295c81af	29	Karnataka	01	Bangalore Urban	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
edf896c8-80e1-4098-a39c-f02052e8e530	29	Karnataka	02	Bangalore Rural	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
9b27233e-b380-4b24-81a8-d6557b578ec2	29	Karnataka	03	Mysore	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
7264ce2a-10b6-44b6-a633-12037a0d0399	29	Karnataka	04	Mangalore	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
52c4d346-02df-408e-bfc4-64709d25d946	33	Tamil Nadu	01	Chennai	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
7ae7d818-51f7-4cdd-bb33-35306b008782	33	Tamil Nadu	02	Coimbatore	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
379b10af-6c3a-4102-8dd6-de036140dbba	33	Tamil Nadu	03	Madurai	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
7329504f-14df-4adb-8ada-79eee0d97cb5	24	Gujarat	01	Ahmedabad	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
5983be16-c9c9-44e0-83da-712909b65ec6	24	Gujarat	02	Surat	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
181a8409-46b9-4fa3-beac-db3a0dcefa8c	24	Gujarat	03	Vadodara	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
d955ab51-5cf0-4584-b099-92f12a763da4	08	Rajasthan	01	Jaipur	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
249b482c-260a-4a2c-ab68-60d45af9b528	08	Rajasthan	02	Jodhpur	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
07bacd9c-645b-4820-bb0c-a1c928c5e69c	08	Rajasthan	03	Udaipur	2025-08-14 07:02:01.604193	2025-08-14 07:02:01.604193
c7099e39-eee9-4c4e-a06f-3e55c8d0c1a9	33	Tamil Nadu	04	Coimbatore	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
ce4bb31e-598e-4f6f-ae70-08d9b50b8205	33	Tamil Nadu	05	Cuddalore	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
b3f21202-d9aa-489a-b1a5-b0651e79ec52	33	Tamil Nadu	06	Dharmapuri	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
137501cb-888e-4af7-a5e5-6bae40718aaa	33	Tamil Nadu	07	Dindigul	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
9b2b5317-830d-474a-b9f6-accf8c94404c	33	Tamil Nadu	08	Erode	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
43ffb2c9-ff3f-4b1e-aecf-6d7a5a14c746	33	Tamil Nadu	09	Kallakurichi	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
79274015-1b44-4784-90ca-0f2efe33e651	33	Tamil Nadu	10	Kanchipuram	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
6a05af76-909c-4ee9-9bb1-fa94bddf2d59	33	Tamil Nadu	11	Kanyakumari	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
382bfd97-440a-474b-9e89-1ab872a93f6f	33	Tamil Nadu	12	Karur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
80fcb30d-714f-43fc-9808-09941b85c91c	33	Tamil Nadu	13	Krishnagiri	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
b02bbd09-f96c-4898-aba0-87b4096d0061	33	Tamil Nadu	14	Madurai	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
b0b79d70-312f-492e-b123-7ae1d6b35c72	33	Tamil Nadu	15	Mayiladuthurai	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
51dace31-6c05-4cd4-a190-1f2662576ee5	33	Tamil Nadu	16	Nagapattinam	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
82430782-a162-4b5c-846c-77621b338659	33	Tamil Nadu	17	Namakkal	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
3e979541-1253-4ead-b307-7fa80bba7fb0	33	Tamil Nadu	18	Nilgiris	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
273d3be7-1392-4af7-97c5-9819669b80b0	33	Tamil Nadu	19	Perambalur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
f03bba2a-91f7-449d-b1e8-2ad27e3c363e	33	Tamil Nadu	20	Pudukkottai	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
68ca80a5-c1ab-4a2d-8bd0-db4619d8ec5f	33	Tamil Nadu	21	Ramanathapuram	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
905a3ae2-b2fb-4e21-977d-7ffaee52719b	33	Tamil Nadu	22	Ranipet	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
35dcf8f9-0617-4fcf-b285-d451f81c189d	33	Tamil Nadu	23	Salem	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
030982ac-74bb-4c75-aa31-5b6d1930383f	33	Tamil Nadu	24	Sivaganga	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
d68df2c1-3ad0-437c-8180-5966c91e20aa	33	Tamil Nadu	25	Tenkasi	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
1706d9bf-8718-45ca-abae-5c4ab09f1c10	33	Tamil Nadu	26	Thanjavur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
150a437f-dbec-4359-b419-21b650e1cce4	33	Tamil Nadu	27	Theni	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
b4d337b7-c099-468c-9c01-103c353020d5	33	Tamil Nadu	28	Thoothukudi	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
700e1bb5-8761-4186-b83e-eb52bf2ec9ef	33	Tamil Nadu	29	Tiruchirappalli	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
93b43411-0ef7-4e16-9f6c-fac5c1e097a5	33	Tamil Nadu	30	Tirunelveli	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
987f2e1a-d38f-455a-b616-1241ccc3ce26	33	Tamil Nadu	31	Tirupattur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
2d32b10e-9cb8-4cff-8e4f-3f47b174fca5	33	Tamil Nadu	32	Tiruppur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
f378ba96-1df7-45fd-bfa4-96f711ce4dfe	33	Tamil Nadu	33	Tiruvallur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
47416b58-c4a7-457b-98a4-5236e24fa55a	33	Tamil Nadu	34	Tiruvannamalai	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
933909d3-1da2-498d-b007-9b3bdc7bb4f9	33	Tamil Nadu	35	Tiruvarur	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
1760c7dc-bb6e-4a95-ba2c-48f620779aa1	33	Tamil Nadu	36	Vellore	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
6ba75478-befc-4c4e-bb09-88222d5dbd35	33	Tamil Nadu	37	Viluppuram	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
c51f26e6-c561-4ad0-80fd-1ddbccf4722a	33	Tamil Nadu	38	Virudhunagar	2025-08-14 07:02:02.034729	2025-08-14 07:02:02.034729
581e3edc-3f6b-4fee-82a6-32d0f3bb017d	29	Karnataka	05	Bengaluru Urban	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
74f71953-d7df-44fd-9be9-46d40f0cf2a4	29	Karnataka	06	Bidar	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
9816d959-c00c-4d1d-875e-8b236bcac136	29	Karnataka	07	Chamarajanagar	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
1ecd4d99-5318-4372-9855-8a2824f67321	29	Karnataka	08	Chikballapur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
01ff405a-f221-470d-86c1-8f61bf7348be	29	Karnataka	09	Chikkamagaluru	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
24118bc4-544f-4f8d-96d2-6232cf9a27e2	29	Karnataka	10	Chitradurga	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
cece0d55-21ce-41bc-8ae9-e83b13c5f7c9	29	Karnataka	11	Dakshina Kannada	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
7e4ecafb-297c-4f99-9328-fd254688d61e	29	Karnataka	12	Davanagere	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
7ed8f69d-8966-45e8-8785-604e3852b8a9	29	Karnataka	13	Dharwad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
9775c951-2d11-403f-8c22-0e2fb1c372e3	29	Karnataka	14	Gadag	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
64106f6b-8b9a-4c89-8593-42365294360d	29	Karnataka	15	Hassan	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
9fae2dad-9828-4b30-8236-dbfdde4e69bd	29	Karnataka	16	Haveri	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
e9e31bcf-bc35-402a-a3fd-c10518bccc85	29	Karnataka	17	Kalaburagi	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
284e5dba-b064-498e-9395-9e27ad4bd880	29	Karnataka	18	Kodagu	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
d1b71978-6f50-4e40-9dec-3e38893f6cb2	29	Karnataka	19	Kolar	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
1c7a70c2-62cf-41c6-8914-c45867e0ab8b	29	Karnataka	20	Koppal	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
31992ea5-561f-498c-9f53-36926b44446d	29	Karnataka	21	Mandya	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
8fcf8312-29fe-4afc-90e8-177827d871b3	29	Karnataka	22	Mysuru	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
fc8f60af-3850-4811-9ee5-66f2f279ac76	29	Karnataka	23	Raichur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
78ea83c8-fb50-4e56-843d-82a7c33914a2	29	Karnataka	24	Ramanagara	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
787dcf83-ca69-441c-a0fa-97af21873f12	29	Karnataka	25	Shivamogga	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
5efb8635-9313-412c-b4be-f30697919362	29	Karnataka	26	Tumakuru	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
fdcabae6-d48c-4d62-9ac8-5a2c502d9a48	29	Karnataka	27	Udupi	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
f75840cd-7593-4257-b5e0-552ff5449887	29	Karnataka	28	Uttara Kannada	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
928c1f77-d029-4466-962c-160af5d30637	29	Karnataka	29	Vijayapura	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
250d53c0-07fd-47e5-a4c7-55fe90200e29	29	Karnataka	30	Yadgir	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
055b6735-5d62-44ff-a339-012be4bec955	32	Kerala	01	Thiruvananthapuram	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
e16ea90b-4578-4f0a-b6f4-fcfd856da60b	32	Kerala	02	Kollam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
a7fcaa41-3c2a-4b01-af52-0fa6faace630	32	Kerala	03	Pathanamthitta	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
025cf0d3-2541-408f-8a7c-43e3df61813d	32	Kerala	04	Alappuzha	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
3a738982-0f32-4241-9971-84dd418b98ba	32	Kerala	05	Kottayam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
55eb6afc-2031-4dda-ac0b-718c11a66105	32	Kerala	06	Idukki	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
62861ea0-f73b-4da2-8d0e-c826d8ec4078	32	Kerala	07	Ernakulam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
86c36954-4f85-4b85-b179-a492306bd43b	32	Kerala	08	Thrissur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
a9db8071-083e-4cdc-a4e5-264fe30f8e74	32	Kerala	09	Palakkad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
db3b4584-a0f5-4332-9061-02fcff9c0882	32	Kerala	10	Malappuram	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
872835b2-1558-428a-b7d8-d029cb2b624f	32	Kerala	11	Kozhikode	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
64c52e20-e424-4199-992b-0cb33940a22c	32	Kerala	12	Wayanad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
5100c530-7bc2-410f-8166-de1dda50f8de	32	Kerala	13	Kannur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
e47b2463-71b9-4a40-9db3-3f1bea24ad3f	32	Kerala	14	Kasaragod	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
8af4ef90-b00a-4b03-9608-e994da064ceb	28	Andhra Pradesh	01	Anantapur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
c97d15e0-2ca8-4984-8a40-84e83dabf0c7	28	Andhra Pradesh	02	Chittoor	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
7eae5051-65f8-4063-a7fc-ece2a2362a10	28	Andhra Pradesh	03	East Godavari	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
39f1f47c-dbb3-4c54-af33-95706151037b	28	Andhra Pradesh	04	Guntur	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
363e2ab9-3392-4c0f-8d44-3dbeddbfb020	28	Andhra Pradesh	05	Krishna	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
8f29586e-68b9-42ec-9b15-8c0b41f65f60	28	Andhra Pradesh	06	Kurnool	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
dd5dfa66-e907-4042-a5ab-b272b89de41d	28	Andhra Pradesh	07	Nellore	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
0264b63e-b64f-4a91-bd16-a24901aafc09	28	Andhra Pradesh	08	Prakasam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
8d9fb949-b74d-4cb9-b8d7-dc16dca53c0d	28	Andhra Pradesh	09	Srikakulam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
6c2e1f72-6b79-4982-953d-40c6bfce0a4a	28	Andhra Pradesh	10	Visakhapatnam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
d3d79b7e-4c38-4eec-901c-1c5f89feed8a	28	Andhra Pradesh	11	Vizianagaram	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
ecd608f9-76d8-4c1f-8bb8-f3fdbdf723b8	28	Andhra Pradesh	12	West Godavari	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
c4c82a75-cf0e-49a4-8081-0a0a4c926f2e	28	Andhra Pradesh	13	YSR Kadapa	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
253f4f13-412c-4de2-b329-ed050bd98014	36	Telangana	01	Adilabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
b1bf86cb-dba7-4ddc-8078-737f5cd70785	36	Telangana	02	Bhadradri Kothagudem	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
0005a423-878b-4570-be0f-63aff779b0a4	36	Telangana	03	Hyderabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
7111cd14-9f53-4fbf-82a4-135917303b68	36	Telangana	04	Jagtial	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
83683934-e831-4f5e-93d6-92349835c378	36	Telangana	05	Jangaon	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
2a6d29d4-58fd-406c-b4a2-0ffc62e42616	36	Telangana	06	Jayashankar Bhoopalpally	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
4943346a-2a9e-4113-a326-e1107ef9db2d	36	Telangana	07	Jogulamba Gadwal	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
601fe9ad-56f8-4add-aa6d-43498ac44690	36	Telangana	08	Kamareddy	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
5bcda354-cd0f-48a0-98c8-8bf64a9018fc	36	Telangana	09	Karimnagar	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
dd58265f-16fb-4b3d-ab65-06ce8778174f	36	Telangana	10	Khammam	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
622680c0-4624-4209-aa63-62ddeef145f5	36	Telangana	11	Komaram Bheem Asifabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
6e903a6e-a0c2-4fe8-9c4b-79480610570a	36	Telangana	12	Mahabubabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
660692a8-6292-454d-a069-1a5a83779e8f	36	Telangana	13	Mahabubnagar	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
cf7251e3-9852-4186-b394-f8f03cbd2c45	36	Telangana	14	Mancherial	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
d89b28b8-2a9b-4363-9659-23125c9d2918	36	Telangana	15	Medak	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
f266da13-6c23-4664-a476-e3c1658a8965	36	Telangana	16	Medchal Malkajgiri	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
e0537f7f-e37c-49c2-8480-d63af3cc8240	36	Telangana	17	Mulugu	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
648d05ff-87b4-47aa-b01a-fd2168b028e7	36	Telangana	18	Nagarkurnool	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
bae0cb48-1321-4cce-8134-239422b4606c	36	Telangana	19	Nalgonda	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
83b6c1ea-4e1f-4422-9910-50a52f0178ed	36	Telangana	20	Narayanpet	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
07756938-b6b4-45a7-a84a-04156da6f1ef	36	Telangana	21	Nirmal	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
04fefed1-afbd-4552-b212-a7095c9a6bde	36	Telangana	22	Nizamabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
12e9cead-168f-4846-83ef-87e64ee4eb4b	36	Telangana	23	Peddapalli	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
a34a6818-0db5-4f1e-9d28-929907ab757c	36	Telangana	24	Rajanna Sircilla	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
3667de86-9169-47d9-9102-b3a0f5ddc0c8	36	Telangana	25	Rangareddy	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
5849dfe0-8b4a-48c6-98f8-220af3d67897	36	Telangana	26	Sangareddy	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
7fbeebe7-a76b-475e-abba-2b13e2525d1c	36	Telangana	27	Siddipet	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
36cc1132-f5a5-4a44-8cf3-d9ac5032fb9a	36	Telangana	28	Suryapet	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
4d02e34e-ea01-4412-a90f-af1e7af2f92e	36	Telangana	29	Vikarabad	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
e965374b-9846-4e04-abea-25ed1b088d13	36	Telangana	30	Wanaparthy	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
5600bb8f-7203-466f-ac0b-e5e845f9a3ad	36	Telangana	31	Warangal Rural	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
2e3d5616-2950-45cf-b6c0-c0306131e372	36	Telangana	32	Warangal Urban	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
96f27d6d-6150-4f73-b928-e2459e5e27ee	36	Telangana	33	Yadadri Bhuvanagiri	2025-08-14 07:02:02.062944	2025-08-14 07:02:02.062944
\.


--
-- TOC entry 3823 (class 0 OID 16587)
-- Dependencies: 228
-- Data for Name: institution; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.institution (id, institution_code, institution_name, created_time, updated_time) FROM stdin;
e6b0ddbd-b54f-4b8c-a48d-c37a7a3841a9	00	School	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
ba158121-a54b-4cba-8708-9c30793811ff	01	Polytechnic	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
cf7aa740-0c78-4102-9947-c9f82c73d255	02	ITI	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
dcf04472-2fab-41c0-b920-44373a7d9250	03	Arts & Science	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
8ce9468f-3f32-4441-a74d-697d4c892a60	04	Engineering	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
fab6f6e7-cd39-465c-b740-d63c1483a447	05	Architecture	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
1456b4ea-1757-4304-b7ba-02cabb8b7634	06	Medical	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
f7bed9de-e362-4fc5-9f95-5d0e81866d97	07	Research Lab	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
01c1449b-8db8-4afc-aa0c-533d52dc6650	08	Entrepreneur	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
0cfea2f9-9a8a-4d30-a3ff-15b197d36b2f	09	Sports Academy	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
56d9e731-2e03-48af-b4f8-2e6e5f2e6e8e	10	Music Academy	2025-08-14 07:02:02.048418	2025-08-14 07:02:02.048418
\.


--
-- TOC entry 3834 (class 0 OID 17687)
-- Dependencies: 239
-- Data for Name: unit; Type: TABLE DATA; Schema: codes; Owner: -
--

COPY codes.unit (id, institution_code, unit_code, unit_name, unit_type, is_active, created_time, updated_time) FROM stdin;
7090d853-1ff1-4e91-bb7a-1c55d031949e	00	ACD	Academics	academic	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
72c8a9b4-b816-412f-b520-f0177e0a830f	00	LIB	Library Services	academic	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
d1438c32-de35-4abd-8cd2-a4de9cafdca6	00	SPT	Sports Department	academic	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
8e104675-ebef-40c8-9e27-eb2e5344219b	00	ADM	Admissions	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
e35c054b-2207-405f-8918-8125b76d8341	00	ADT	Administration	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
2f53e8a2-aedc-4018-a782-846cec91a9a8	00	FIN	Finance	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
26db51e7-e019-491d-8461-fbd70ba32d27	00	HRD	Human Resources	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
be817315-27ee-40b7-a929-87d26d6e0821	00	ICT	Information Technology	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
69aa7fdf-5ce9-4bbc-a04c-2dade99f53ee	00	OPS	Operations	administrative	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
2d58f1a6-102e-42de-8ca1-4ad21cf6047e	00	MKT	Marketing	communication	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
3c7a7cdd-1c3d-4990-8652-9b458bbf9f26	00	COM	Communication	communication	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
304836d5-534d-47fb-bb16-65fc9257bf06	00	PRM	Public Relations & Media	communication	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
ddb32637-e3ce-4067-8984-1a2d3e7180bd	00	CRM	Customer Relationship Management	communication	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
9661c834-70a0-42d9-a3cc-27cda2795793	00	LOG	Logistics	support	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
8f4986e5-0223-4a90-b23a-e001a0ec20e8	00	FOD	Food	support	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
7d07f5df-ab75-4351-9e1f-f4cedabf3b23	00	HWS	Health and Wellness	support	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
a0d7f125-a088-4de3-8831-ed9cc3cd4dda	00	TSP	Transport	support	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
d826aa5c-da7f-4abf-85e7-3ff20502cc35	00	LBS	Library	support	t	2025-08-20 13:29:32.739829	2025-08-20 13:29:32.739829
\.


--
-- TOC entry 3824 (class 0 OID 16594)
-- Dependencies: 229
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	create admissions schema and tables	SQL	V1__create_admissions_schema_and_tables.sql	1006316641	postgres	2025-08-14 07:00:45.916513	64	t
2	2	rename entrance scores column	SQL	V2__rename_entrance_scores_column.sql	-2062170264	postgres	2025-08-14 07:00:46.006828	3	t
3	3	enforce id lengths	SQL	V3__enforce_id_lengths.sql	-878794859	postgres	2025-08-14 07:00:46.029441	10	t
4	4	enforce id length appid	SQL	V4__enforce_id_length_appid.sql	-1595366025	postgres	2025-08-14 07:00:46.056801	11	t
5	5	marksheet document id to uuid	SQL	V5__marksheet_document_id_to_uuid.sql	-955770609	postgres	2025-08-14 07:00:46.076365	19	t
6	6	remove composite pks from marksheet document	SQL	V6__remove_composite_pks_from_marksheet_document.sql	1247627638	postgres	2025-08-14 07:00:46.103006	2	t
7	7	drop docuement ref	SQL	V7__drop_docuement_ref.sql	1408636826	postgres	2025-08-14 07:00:46.110867	4	t
8	8	admissions enhancements	SQL	V8__admissions_enhancements.sql	-1708413012	postgres	2025-08-14 07:00:46.120232	12	t
9	9	create users schema	SQL	V9__create_users_schema.sql	394948784	postgres	2025-08-14 07:00:46.139438	27	t
10	10	update admissions schema for user reference	SQL	V10__update_admissions_schema_for_user_reference.sql	1075239753	postgres	2025-08-14 07:00:46.17338	6	t
11	11	add deleted at column	SQL	V11__add_deleted_at_column.sql	1738043716	postgres	2025-08-14 07:00:46.18573	3	t
12	12	rename fee status to payment status	SQL	V12__rename_fee_status_to_payment_status.sql	889427579	postgres	2025-08-14 07:00:46.192524	3	t
13	13	add academic year to application	SQL	V13__add_academic_year_to_application.sql	1618391016	postgres	2025-08-14 07:00:46.200322	4	t
14	14	add current academic year to student	SQL	V14__add_current_academic_year_to_student.sql	491402333	postgres	2025-08-14 07:00:46.209569	6	t
15	15	update student mobile and constraints	SQL	V15__update_student_mobile_and_constraints.sql	-1016008248	postgres	2025-08-14 07:00:46.219634	7	t
16	16	rename contact to landline	SQL	V16__rename_contact_to_landline.sql	-63805761	postgres	2025-08-14 07:00:46.234865	2	t
17	17	move columns to users schema	SQL	V17__move_columns_to_users_schema.sql	-1486617658	postgres	2025-08-14 07:00:46.240515	97	t
18	18	create users application table	SQL	V18__create_users_application_table.sql	1149495473	postgres	2025-08-14 07:00:46.351141	26	t
19	18.1	baseline after manual changes	SQL	V18.1__baseline_after_manual_changes.sql	594319748	postgres	2025-08-14 07:00:46.383594	4	t
20	19	drop admissions schema	SQL	V19__drop_admissions_schema.sql	1798703461	postgres	2025-08-14 07:00:46.391767	10	t
21	20	add branch id to offer letter	SQL	V20__add_branch_id_to_offer_letter.sql	-234395845	postgres	2025-08-14 07:00:46.407606	2	t
22	21	remove columns from student and application	SQL	V21__remove_columns_from_student_and_application.sql	-519119426	postgres	2025-08-14 07:00:46.414732	2	t
23	22	update student table columns	SQL	V22__update_student_table_columns.sql	-824029436	postgres	2025-08-14 07:00:46.420155	2	t
24	23	add unique constraints to student	SQL	V23__add_unique_constraints_to_student.sql	118658263	postgres	2025-08-14 07:00:46.425581	8	t
25	24	add cascade delete to application fks	SQL	V24__add_cascade_delete_to_application_fks.sql	-1662971999	postgres	2025-08-14 07:00:46.437692	11	t
26	25	remove deleted at and rename academic data	SQL	V25__remove_deleted_at_and_rename_academic_data.sql	-1197328565	postgres	2025-08-14 07:00:46.452728	2	t
27	26	add admin verification tracking	SQL	V26__add_admin_verification_tracking.sql	-7754051	postgres	2025-08-14 07:00:46.459038	47	t
28	27	drop offer letter table	SQL	V27__drop_offer_letter_table.sql	-138120434	postgres	2025-08-14 07:00:46.514746	3	t
29	28	drop entrance exam table	SQL	V28__drop_entrance_exam_table.sql	1474272066	postgres	2025-08-14 07:00:46.522004	3	t
30	29	drop review outcome table	SQL	V29__drop_review_outcome_table.sql	1593831654	postgres	2025-08-14 07:00:46.529576	3	t
31	30	add draft expiry tracking	SQL	V30__add_draft_expiry_tracking.sql	1800224039	postgres	2025-08-14 07:00:46.536483	4	t
32	31	enforce branch id length constraint	SQL	V31__enforce_branch_id_length_constraint.sql	752291936	postgres	2025-08-14 07:00:46.544411	105	t
33	33	setup 12digit system new apps	SQL	V33__setup_12digit_system_new_apps.sql	527160274	postgres	2025-08-14 07:00:46.660227	33	t
34	34	create 16digit system with comprehensive codes	SQL	V34__create_16digit_system_with_comprehensive_codes.sql	-1744305093	postgres	2025-08-14 07:00:46.700739	31	t
35	35	fix application table structure	SQL	V35__fix_application_table_structure.sql	1740755173	postgres	2025-08-14 07:00:46.742429	59	t
36	36	recreate complete schema with codes	SQL	V36__recreate_complete_schema_with_codes.sql	-1029208549	postgres	2025-08-14 07:02:01.5511	210	t
37	37	fix table naming and add complete hierarchy	SQL	V37__fix_table_naming_and_add_complete_hierarchy.sql	792090336	postgres	2025-08-14 07:02:01.819797	2	t
38	38	add complete geographic hierarchy	SQL	V38__add_complete_geographic_hierarchy.sql	1708142488	postgres	2025-08-14 07:02:01.831149	62	t
39	39	make student academic year communication address not null	SQL	V39__make_student_academic_year_communication_address_not_null.sql	1681631679	postgres	2025-08-14 07:02:01.920349	6	t
40	40	add communication address columns to student	SQL	V40__add_communication_address_columns_to_student.sql	-1765279075	postgres	2025-08-14 07:02:01.934621	18	t
41	41	refactor codes schema and branch address	SQL	V41__refactor_codes_schema_and_branch_address.sql	2087964147	postgres	2025-08-14 07:02:01.959252	40	t
42	42	remove id sequences table	SQL	V42__remove_id_sequences_table.sql	636594851	postgres	2025-08-14 07:02:02.009667	15	t
43	43	add tamilnadu districts remove is active	SQL	V43__add_tamilnadu_districts_remove_is_active.sql	-732011292	postgres	2025-08-14 07:02:02.031301	6	t
44	44	refactor institution table add types	SQL	V44__refactor_institution_table_add_types.sql	-1479257243	postgres	2025-08-14 07:02:02.044913	9	t
45	45	add south indian states districts	SQL	V45__add_south_indian_states_districts.sql	39648518	postgres	2025-08-14 07:02:02.059104	4	t
46	46	add tamilnadu branches	SQL	V46__add_tamilnadu_branches.sql	1114146137	postgres	2025-08-14 07:02:02.069561	4	t
47	47	fix branch code unique constraint per district	SQL	V47__fix_branch_code_unique_constraint_per_district.sql	-2077326818	postgres	2025-08-14 07:02:02.077712	62	t
48	48	implement branch based curriculum system	SQL	V48__implement_branch_based_curriculum_system.sql	1486855956	postgres	2025-08-14 07:02:02.145532	38	t
49	49	populate branch institutions and school curriculum	SQL	V49__populate_branch_institutions_and_school_curriculum.sql	-424491463	postgres	2025-08-14 07:02:02.190899	8	t
50	50	update academic curriculum constraints	SQL	V50__update_academic_curriculum_constraints.sql	1084947363	postgres	2025-08-14 07:02:02.209589	7	t
51	51	refactor curriculum remove branch duplication	SQL	V51__refactor_curriculum_remove_branch_duplication.sql	-87302857	postgres	2025-08-14 07:02:02.220738	14	t
52	52	optimize curriculum remove class code add samples	SQL	V52__optimize_curriculum_remove_class_code_add_samples.sql	495218185	postgres	2025-08-14 07:02:02.243102	22	t
53	53	remove application id use enrollment id only	SQL	V53__remove_application_id_use_enrollment_id_only.sql	939240523	postgres	2025-08-15 23:46:39.597388	23	t
54	54	remove geographic fields from document verification	SQL	V54__remove_geographic_fields_from_document_verification.sql	1843836793	postgres	2025-08-17 01:06:15.358604	18	t
55	55	create auth schema	SQL	V55__create_auth_schema.sql	-1356001896	postgres	2025-08-18 20:46:55.71589	975	t
56	56	fix auth schema timestamp conventions	SQL	V56__fix_auth_schema_timestamp_conventions.sql	741044949	postgres	2025-08-20 12:25:09.981617	91	t
57	57	seed opa users and role assignments	SQL	V57__seed_opa_users_and_role_assignments.sql	-1414410205	postgres	2025-08-20 12:25:51.464112	98	t
58	58	create codes unit table	SQL	V58__create_codes_unit_table.sql	1201583964	postgres	2025-08-20 13:29:32.55245	70	t
59	59	create codes branch institution unit table	SQL	V59__create_codes_branch_institution_unit_table.sql	132773273	postgres	2025-08-20 13:29:32.660489	37	t
60	60	seed school units data	SQL	V60__seed_school_units_data.sql	-734776270	postgres	2025-08-20 13:29:32.71443	19	t
61	61	extend auth user roles for units	SQL	V61__extend_auth_user_roles_for_units.sql	88289238	postgres	2025-08-20 13:29:32.764184	36	t
62	62	create branch institution unit view	SQL	V62__create_branch_institution_unit_view.sql	1565362404	postgres	2025-08-20 16:40:25.677141	27	t
63	63	remove unused permissions tables	SQL	V63__remove_unused_permissions_tables.sql	791228778	postgres	2025-08-20 16:55:36.672628	37	t
64	64	redesign roles for unit hierarchy	SQL	V64__redesign_roles_for_unit_hierarchy.sql	1279205181	postgres	2025-08-20 17:07:58.821423	35	t
65	65	create universal roles and migrate assignments	SQL	V65__create_universal_roles_and_migrate_assignments.sql	-299931218	postgres	2025-08-20 17:08:53.000014	55	t
66	66	cleanup legacy department roles	SQL	V66__cleanup_legacy_department_roles.sql	14217457	postgres	2025-08-20 17:13:36.805757	57	t
67	67	ultimate role simplification embed in users	SQL	V67__ultimate_role_simplification_embed_in_users.sql	-1735162375	postgres	2025-08-20 17:29:27.745563	132	t
68	68	drop user roles table	SQL	V68__drop_user_roles_table.sql	-412276679	postgres	2025-08-20 17:30:32.741966	65	t
69	69	delete legacy roles	SQL	V69__delete_legacy_roles.sql	-1672439718	postgres	2025-08-20 17:31:10.836949	42	t
70	70	drop auth views	SQL	V70__drop_auth_views.sql	2059380951	postgres	2025-08-20 17:48:49.132068	27	t
71	71	drop audit tables	SQL	V71__drop_audit_tables.sql	-1491165890	postgres	2025-08-20 17:49:22.489255	38	t
72	72	embed password reset tokens	SQL	V72__embed_password_reset_tokens.sql	212313532	postgres	2025-08-20 17:50:17.505352	174	t
73	73	enhance roles with unit fkeys	SQL	V73__enhance_roles_with_unit_fkeys.sql	-357264884	postgres	2025-08-20 17:51:01.13939	55	t
\.


--
-- TOC entry 3825 (class 0 OID 16600)
-- Dependencies: 230
-- Data for Name: academic; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.academic (id, enrollment_id, program_code, department_code, entrance_score, ai_score, last_institution, academic_records, document_records, created_time, updated_time, institution_code) FROM stdin;
18c50ad8-e422-4059-bcde-a32c9af723d2	3326110026526097	S03	PRI	92	50	\N	\N	\N	2025-08-20 11:23:34.703132	2025-08-20 11:23:46.888868	00
\.


--
-- TOC entry 3826 (class 0 OID 16610)
-- Dependencies: 231
-- Data for Name: application; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.application (id, enrollment_id, application_status, state_code, district_code, branch_code, institution_code, academic_year, created_time, updated_time, submitted_time, reviewed_time, reviewer_name, draft_expires_time, last_expiry_check_time, expiry_processed, offer_issued_time, offer_response_time, fees_paid_time, enrolled_time) FROM stdin;
f30132a0-ca3d-44ec-959d-203c28afb901	3326110026526097	enrolled	33	26	11	00	2025-26	2025-08-20 11:23:34.703132	2025-08-20 11:23:56.997216	2025-08-20 11:23:38.768063	2025-08-20 11:23:50	K6 Test Admin	2025-08-20 11:33:36.75553	0001-01-01 00:00:00	f	2025-08-20 11:23:52	2025-08-20 11:23:54	2025-08-20 11:23:56	2025-08-20 11:23:56.997216
ca82e1e8-74c7-4036-a711-8dda9f282508	3326110426590721	enrolled	33	26	11	04	2025-26	2025-08-20 11:24:02.015122	2025-08-20 11:24:25.365921	2025-08-20 11:24:06.103549	2025-08-20 11:24:19	K6 Test Admin	2025-08-20 11:34:04.08723	0001-01-01 00:00:00	f	2025-08-20 11:24:21	2025-08-20 11:24:23	2025-08-20 11:24:25	2025-08-20 11:24:25.365921
\.


--
-- TOC entry 3827 (class 0 OID 16624)
-- Dependencies: 232
-- Data for Name: document; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.document (id, doc_type, name, url, created_time, updated_time, enrollment_id) FROM stdin;
924dcbd8-151f-4620-b432-a1a7afce2b03	birth_certificate	Birth Certificate	https://storage.example.com/documents/birth_certificate.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
9cb7e80a-fca3-47c6-b4f7-b3686702ffbd	aadhaar	Aadhaar Card	https://storage.example.com/documents/aadhaar_card.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
827e16a7-63ff-4bad-81d4-c4c51dadc8d6	aapaar	APAAR ID	https://storage.example.com/documents/apaar_id.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
cd6967fd-8b11-4306-8b3c-ac6b4e390dbe	photograph	Passport Size Photograph	https://storage.example.com/documents/student_photo.jpg	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
bb6bbc45-8ebf-4901-83bd-b7c62c3c4501	previous_marksheet	Previous School Marksheet	https://storage.example.com/documents/previous_marksheet.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
10b64479-ae89-48e6-8768-ec6334a975a1	conduct_certificate	Conduct Certificate	https://storage.example.com/documents/conduct_certificate.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
17804e38-d914-4354-a803-d4b4a6db212f	transfer_certificate	Transfer Certificate	https://storage.example.com/documents/transfer_certificate.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110026526097
c4fdcba2-bc1a-41a7-bc43-c12e2bf0ff6a	birth_certificate	Birth Certificate	https://storage.example.com/documents/birth_certificate_college.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
f75d9023-b66d-4253-8688-a84797857f70	aadhaar	Aadhaar Card	https://storage.example.com/documents/aadhaar_card_college.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
890f5a8a-bb28-4ce0-a146-e1d7d3497673	aapaar	APAAR ID	https://storage.example.com/documents/apaar_id_college.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
30ab62b2-8567-46c1-b12e-4afc2666d1b0	photograph	Passport Size Photograph	https://storage.example.com/documents/student_photo_college.jpg	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
0c54d2ff-1797-49c3-a1f3-c313992311d0	10th_marksheet	Class X Marksheet	https://storage.example.com/documents/10th_marksheet.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
22be72d4-d48f-4500-bd3a-d4401ba64d70	12th_marksheet	Class XII Marksheet	https://storage.example.com/documents/12th_marksheet.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
109c1681-e43c-4ef6-95f6-4a9446050859	conduct_certificate	Conduct Certificate	https://storage.example.com/documents/conduct_certificate_college.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
000ae7ca-073f-4f72-97a8-b20875d4f33e	migration_certificate	Migration Certificate	https://storage.example.com/documents/migration_certificate.pdf	0001-01-01 00:00:00	0001-01-01 00:00:00	3326110426590721
\.


--
-- TOC entry 3828 (class 0 OID 16632)
-- Dependencies: 233
-- Data for Name: document_verification; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.document_verification (id, document_type, admin_id, admin_name, status, comments, verified_time, created_time, updated_time, enrollment_id) FROM stdin;
5664b57f-b076-4579-a58e-1775c628225f	birth_certificate	admin-k6-tester	K6 Test Admin	verified	birth_certificate verified by k6 test.	2025-08-20 11:23:41	2025-08-20 11:23:41.796013	2025-08-20 11:23:41.796014	3326110026526097
efdd78d4-ed60-4254-be82-fc4c739fb9f6	aadhaar	admin-k6-tester	K6 Test Admin	verified	aadhaar verified by k6 test.	2025-08-20 11:23:42	2025-08-20 11:23:42.825129	2025-08-20 11:23:42.825129	3326110026526097
05371803-89a4-469c-9f31-4536f5800de4	aapaar	admin-k6-tester	K6 Test Admin	verified	aapaar verified by k6 test.	2025-08-20 11:23:43	2025-08-20 11:23:43.836037	2025-08-20 11:23:43.836037	3326110026526097
0522d8a5-717f-41e9-b2d1-9a0939792728	photograph	admin-k6-tester	K6 Test Admin	verified	photograph verified by k6 test.	2025-08-20 11:23:44	2025-08-20 11:23:44.85353	2025-08-20 11:23:44.853531	3326110026526097
9a4e5358-3ac3-46fb-bab6-96d8cbcd5de4	previous_marksheet	admin-k6-tester	K6 Test Admin	verified	previous_marksheet verified by k6 test.	2025-08-20 11:23:45	2025-08-20 11:23:45.864912	2025-08-20 11:23:45.864912	3326110026526097
6ce44f28-e18f-4261-97dc-0c9d65770b92	conduct_certificate	admin-k6-tester	K6 Test Admin	verified	conduct_certificate verified by k6 test.	2025-08-20 11:23:46	2025-08-20 11:23:46.875349	2025-08-20 11:23:46.875349	3326110026526097
9af86fb9-cdd0-4066-987d-4a18c1e0999a	birth_certificate	admin-k6-tester	K6 Test Admin	verified	birth_certificate verified by k6 test.	2025-08-20 11:24:09	2025-08-20 11:24:09.149397	2025-08-20 11:24:09.149397	3326110426590721
0c079083-a0c2-4d2c-bf96-aafb0a9eb08b	aadhaar	admin-k6-tester	K6 Test Admin	verified	aadhaar verified by k6 test.	2025-08-20 11:24:10	2025-08-20 11:24:10.167253	2025-08-20 11:24:10.167253	3326110426590721
fc790058-3fa3-4aac-8953-e1623812d6bf	aapaar	admin-k6-tester	K6 Test Admin	verified	aapaar verified by k6 test.	2025-08-20 11:24:11	2025-08-20 11:24:11.179886	2025-08-20 11:24:11.179887	3326110426590721
62527603-3604-4841-95ec-646dc160440c	photograph	admin-k6-tester	K6 Test Admin	verified	photograph verified by k6 test.	2025-08-20 11:24:12	2025-08-20 11:24:12.19721	2025-08-20 11:24:12.19721	3326110426590721
47583ae4-2237-457a-951f-ef054a986dc3	10th_marksheet	admin-k6-tester	K6 Test Admin	verified	10th_marksheet verified by k6 test.	2025-08-20 11:24:13	2025-08-20 11:24:13.221824	2025-08-20 11:24:13.221824	3326110426590721
227396c6-9e94-4516-9910-6b098662a587	12th_marksheet	admin-k6-tester	K6 Test Admin	verified	12th_marksheet verified by k6 test.	2025-08-20 11:24:14	2025-08-20 11:24:14.23749	2025-08-20 11:24:14.23749	3326110426590721
17e209e6-196d-46a1-815e-7507d2b299dd	conduct_certificate	admin-k6-tester	K6 Test Admin	verified	conduct_certificate verified by k6 test.	2025-08-20 11:24:15	2025-08-20 11:24:15.248518	2025-08-20 11:24:15.248518	3326110426590721
\.


--
-- TOC entry 3829 (class 0 OID 16641)
-- Dependencies: 234
-- Data for Name: parent; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.parent (id, enrollment_id, parent_type, name, qualification, profession, annual_earnings, pan_card, contact_number, email, alternate_number, created_time, updated_time) FROM stdin;
299777d5-18ac-41a7-a126-0b2bb3257a15	3326110026526097	father	Carlos Garcia	B.Tech	Engineer	1200000	ABCDE1234F	9876543210	carlos.father@example.com	\N	0001-01-01 00:00:00	0001-01-01 00:00:00
c1ac0b2d-38e3-4c99-a226-0c94eb0b3e27	3326110026526097	mother	Ana Garcia	M.Sc.	Teacher	800000	FGHIJ5678K	8765432109	ana.mother@example.com	\N	0001-01-01 00:00:00	0001-01-01 00:00:00
\.


--
-- TOC entry 3830 (class 0 OID 16653)
-- Dependencies: 235
-- Data for Name: sibling; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.sibling (id, enrollment_id, name, age, gender, school, class, created_time, updated_time) FROM stdin;
fd140158-890e-488f-aa34-503b80207ce2	3326110026526097	Jane Doe	15	Female			0001-01-01 00:00:00	0001-01-01 00:00:00
d57a986f-dfe7-4d4d-90a6-c6df5262184a	3326110426590721		0	Female			0001-01-01 00:00:00	0001-01-01 00:00:00
\.


--
-- TOC entry 3831 (class 0 OID 16662)
-- Dependencies: 236
-- Data for Name: skill; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.skill (id, enrollment_id, skill_name, skill_category, proficiency_level, certification_details, acquired_date, last_updated_date, branch_code, is_active, created_time, updated_time, state_code, district_code, institution_code) FROM stdin;
\.


--
-- TOC entry 3832 (class 0 OID 16677)
-- Dependencies: 237
-- Data for Name: sport; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.sport (id, enrollment_id, sport_name, sport_category, skill_level, participation_year, achievements, coach_name, training_hours_per_week, branch_code, is_active, created_time, updated_time, state_code, district_code, institution_code) FROM stdin;
\.


--
-- TOC entry 3833 (class 0 OID 16693)
-- Dependencies: 238
-- Data for Name: student; Type: TABLE DATA; Schema: users; Owner: -
--

COPY users.student (id, enrollment_id, roll_no, first_name, middle_name, surname, date_of_birth, gender, blood_group, mother_tongue, nationality, religion, category, email, aadhaar_id, apaar_id, primary_mobile, alternative_mobile, landline_number, alternate_landline_number, permanent_address, branch_code, academic_year, created_time, updated_time, state_code, district_code, institution_code, communication_street, communication_address, communication_doorno, communication_city, communication_district, communication_pincode, emis_no) FROM stdin;
d0c59ca3-ecb1-438e-8aec-a8f79de54c37	3326110026526097	2025109	Maria	HelloThere	Garcia	10-05-2015	Female	O+	English	India	Hindu	General	school-student-17556692147001@example.com	856692147001	856692147001	97556692147001	8765432119	0112345678	0223456789	{"city": "Delhi", "state": "Delhi", "pincode": "110001", "district": "New Delhi", "address_line1": "123 Main Street", "address_line2": "Apartment 4B"}	11	2025-26	0001-01-01 00:00:00	0001-01-01 00:00:00	33	26	00	123 Main Street	123 Main Street, Apartment 4B	4B	Delhi	New Delhi	110001	\N
32c07b95-c34f-4c88-a2cd-1543f3ffbe7b	3326110426590721	2025103	Rajesh	HelloThere	Sharma	15-08-2005	Male	B+	Hindi	India	Hindu	General	college-student-17556692420001@example.com	856692420001	856692420001	97556692420001	8765432110	0112345679	0223456790	{"city": "Mumbai", "state": "Maharashtra", "pincode": "400001", "district": "Mumbai", "address_line1": "456 College Street", "address_line2": "Apartment 7A"}	11	2025-26	0001-01-01 00:00:00	0001-01-01 00:00:00	33	26	04	456 College Street	456 College Street, Apartment 7A	7A	Mumbai	Mumbai	400001	\N
\.


--
-- TOC entry 3512 (class 2606 OID 16753)
-- Name: branch branch_code_unique_per_district; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch
    ADD CONSTRAINT branch_code_unique_per_district UNIQUE (state_code, district_code, branch_code);


--
-- TOC entry 3892 (class 0 OID 0)
-- Dependencies: 3512
-- Name: CONSTRAINT branch_code_unique_per_district ON branch; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON CONSTRAINT branch_code_unique_per_district ON codes.branch IS 'Branch code must be unique within each district (state_code + district_code + branch_code combination)';


--
-- TOC entry 3522 (class 2606 OID 16755)
-- Name: branch_institution branch_institution_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution
    ADD CONSTRAINT branch_institution_pkey PRIMARY KEY (id);


--
-- TOC entry 3524 (class 2606 OID 16757)
-- Name: branch_institution branch_institution_unique; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution
    ADD CONSTRAINT branch_institution_unique UNIQUE (state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3641 (class 2606 OID 17718)
-- Name: branch_institution_unit branch_institution_unit_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution_unit
    ADD CONSTRAINT branch_institution_unit_pkey PRIMARY KEY (id);


--
-- TOC entry 3643 (class 2606 OID 17720)
-- Name: branch_institution_unit branch_institution_unit_unique; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution_unit
    ADD CONSTRAINT branch_institution_unit_unique UNIQUE (state_code, district_code, branch_code, institution_code, unit_code);


--
-- TOC entry 3514 (class 2606 OID 16759)
-- Name: branch branch_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch
    ADD CONSTRAINT branch_pkey PRIMARY KEY (id);


--
-- TOC entry 3529 (class 2606 OID 16761)
-- Name: curriculum curriculum_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.curriculum
    ADD CONSTRAINT curriculum_pkey PRIMARY KEY (id);


--
-- TOC entry 3531 (class 2606 OID 16763)
-- Name: curriculum curriculum_unique_optimized; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.curriculum
    ADD CONSTRAINT curriculum_unique_optimized UNIQUE (institution_code, program_code, department_code);


--
-- TOC entry 3893 (class 0 OID 0)
-- Dependencies: 3531
-- Name: CONSTRAINT curriculum_unique_optimized ON curriculum; Type: COMMENT; Schema: codes; Owner: -
--

COMMENT ON CONSTRAINT curriculum_unique_optimized ON codes.curriculum IS 'Simplified unique constraint without redundant class_code';


--
-- TOC entry 3543 (class 2606 OID 16765)
-- Name: geographic geographic_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.geographic
    ADD CONSTRAINT geographic_pkey PRIMARY KEY (id);


--
-- TOC entry 3545 (class 2606 OID 16767)
-- Name: geographic geographic_state_code_district_code_key; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.geographic
    ADD CONSTRAINT geographic_state_code_district_code_key UNIQUE (state_code, district_code);


--
-- TOC entry 3549 (class 2606 OID 16769)
-- Name: institution institution_code_unique; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.institution
    ADD CONSTRAINT institution_code_unique UNIQUE (institution_code);


--
-- TOC entry 3551 (class 2606 OID 16771)
-- Name: institution institution_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.institution
    ADD CONSTRAINT institution_pkey PRIMARY KEY (id);


--
-- TOC entry 3637 (class 2606 OID 17697)
-- Name: unit unit_code_unique; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.unit
    ADD CONSTRAINT unit_code_unique UNIQUE (institution_code, unit_code);


--
-- TOC entry 3639 (class 2606 OID 17695)
-- Name: unit unit_pkey; Type: CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (id);


--
-- TOC entry 3553 (class 2606 OID 16773)
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- TOC entry 3556 (class 2606 OID 16775)
-- Name: academic academic_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.academic
    ADD CONSTRAINT academic_pkey PRIMARY KEY (id);


--
-- TOC entry 3559 (class 2606 OID 16777)
-- Name: application application_enrollment_id_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.application
    ADD CONSTRAINT application_enrollment_id_key UNIQUE (enrollment_id);


--
-- TOC entry 3561 (class 2606 OID 16779)
-- Name: application application_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.application
    ADD CONSTRAINT application_pkey PRIMARY KEY (id);


--
-- TOC entry 3569 (class 2606 OID 16781)
-- Name: document document_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (id);


--
-- TOC entry 3572 (class 2606 OID 16783)
-- Name: document_verification document_verification_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.document_verification
    ADD CONSTRAINT document_verification_pkey PRIMARY KEY (id);


--
-- TOC entry 3583 (class 2606 OID 16785)
-- Name: parent parent_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.parent
    ADD CONSTRAINT parent_pkey PRIMARY KEY (id);


--
-- TOC entry 3586 (class 2606 OID 16787)
-- Name: sibling sibling_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sibling
    ADD CONSTRAINT sibling_pkey PRIMARY KEY (id);


--
-- TOC entry 3595 (class 2606 OID 16789)
-- Name: skill skills_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.skill
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- TOC entry 3604 (class 2606 OID 16791)
-- Name: sport sports_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sport
    ADD CONSTRAINT sports_pkey PRIMARY KEY (id);


--
-- TOC entry 3619 (class 2606 OID 16793)
-- Name: student student_aadhaar_id_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_aadhaar_id_key UNIQUE (aadhaar_id);


--
-- TOC entry 3621 (class 2606 OID 16795)
-- Name: student student_apaar_id_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_apaar_id_key UNIQUE (apaar_id);


--
-- TOC entry 3623 (class 2606 OID 16797)
-- Name: student student_email_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_email_key UNIQUE (email);


--
-- TOC entry 3625 (class 2606 OID 16799)
-- Name: student student_enrollment_id_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_enrollment_id_key UNIQUE (enrollment_id);


--
-- TOC entry 3627 (class 2606 OID 16801)
-- Name: student student_pkey; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- TOC entry 3629 (class 2606 OID 16803)
-- Name: student student_primary_mobile_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_primary_mobile_key UNIQUE (primary_mobile);


--
-- TOC entry 3631 (class 2606 OID 16805)
-- Name: student student_roll_no_branch_code_academic_year_key; Type: CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_roll_no_branch_code_academic_year_key UNIQUE (roll_no, branch_code, academic_year);


--
-- TOC entry 3532 (class 1259 OID 16835)
-- Name: idx_academic_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_academic_active ON codes.curriculum USING btree (is_active);


--
-- TOC entry 3533 (class 1259 OID 16836)
-- Name: idx_academic_department; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_academic_department ON codes.curriculum USING btree (department_code);


--
-- TOC entry 3534 (class 1259 OID 16837)
-- Name: idx_academic_level; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_academic_level ON codes.curriculum USING btree (academic_level);


--
-- TOC entry 3535 (class 1259 OID 16838)
-- Name: idx_academic_program; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_academic_program ON codes.curriculum USING btree (program_code);


--
-- TOC entry 3515 (class 1259 OID 16839)
-- Name: idx_branch_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_active ON codes.branch USING btree (is_active);


--
-- TOC entry 3516 (class 1259 OID 16840)
-- Name: idx_branch_address_city; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_address_city ON codes.branch USING btree (address_city);


--
-- TOC entry 3517 (class 1259 OID 16841)
-- Name: idx_branch_address_district; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_address_district ON codes.branch USING btree (address_district);


--
-- TOC entry 3518 (class 1259 OID 16842)
-- Name: idx_branch_address_location; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_address_location ON codes.branch USING btree (address_city, address_district);


--
-- TOC entry 3519 (class 1259 OID 16843)
-- Name: idx_branch_address_pincode; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_address_pincode ON codes.branch USING btree (address_pincode);


--
-- TOC entry 3520 (class 1259 OID 16844)
-- Name: idx_branch_geographic; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_geographic ON codes.branch USING btree (state_code, district_code);


--
-- TOC entry 3525 (class 1259 OID 16845)
-- Name: idx_branch_institution_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_active ON codes.branch_institution USING btree (is_active);


--
-- TOC entry 3526 (class 1259 OID 16846)
-- Name: idx_branch_institution_branch; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_branch ON codes.branch_institution USING btree (state_code, district_code, branch_code);


--
-- TOC entry 3527 (class 1259 OID 16847)
-- Name: idx_branch_institution_type; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_type ON codes.branch_institution USING btree (institution_code);


--
-- TOC entry 3644 (class 1259 OID 17734)
-- Name: idx_branch_institution_unit_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_unit_active ON codes.branch_institution_unit USING btree (is_active);


--
-- TOC entry 3645 (class 1259 OID 17731)
-- Name: idx_branch_institution_unit_branch; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_unit_branch ON codes.branch_institution_unit USING btree (state_code, district_code, branch_code);


--
-- TOC entry 3646 (class 1259 OID 17762)
-- Name: idx_branch_institution_unit_details_lookup; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_unit_details_lookup ON codes.branch_institution_unit USING btree (institution_code, unit_code);


--
-- TOC entry 3647 (class 1259 OID 17732)
-- Name: idx_branch_institution_unit_institution; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_unit_institution ON codes.branch_institution_unit USING btree (institution_code);


--
-- TOC entry 3648 (class 1259 OID 17733)
-- Name: idx_branch_institution_unit_unit; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_branch_institution_unit_unit ON codes.branch_institution_unit USING btree (unit_code);


--
-- TOC entry 3536 (class 1259 OID 16848)
-- Name: idx_curriculum_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_active ON codes.curriculum USING btree (is_active);


--
-- TOC entry 3537 (class 1259 OID 16849)
-- Name: idx_curriculum_department; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_department ON codes.curriculum USING btree (department_code);


--
-- TOC entry 3538 (class 1259 OID 16850)
-- Name: idx_curriculum_institution; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_institution ON codes.curriculum USING btree (institution_code);


--
-- TOC entry 3539 (class 1259 OID 16851)
-- Name: idx_curriculum_level; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_level ON codes.curriculum USING btree (academic_level);


--
-- TOC entry 3540 (class 1259 OID 16852)
-- Name: idx_curriculum_optimized_lookup; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_optimized_lookup ON codes.curriculum USING btree (institution_code, program_code, department_code);


--
-- TOC entry 3541 (class 1259 OID 16853)
-- Name: idx_curriculum_program; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_curriculum_program ON codes.curriculum USING btree (program_code);


--
-- TOC entry 3546 (class 1259 OID 16854)
-- Name: idx_geographic_district; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_geographic_district ON codes.geographic USING btree (state_code, district_code);


--
-- TOC entry 3547 (class 1259 OID 16855)
-- Name: idx_geographic_state; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_geographic_state ON codes.geographic USING btree (state_code);


--
-- TOC entry 3632 (class 1259 OID 17704)
-- Name: idx_unit_active; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_unit_active ON codes.unit USING btree (is_active);


--
-- TOC entry 3633 (class 1259 OID 17705)
-- Name: idx_unit_code; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_unit_code ON codes.unit USING btree (unit_code);


--
-- TOC entry 3634 (class 1259 OID 17703)
-- Name: idx_unit_institution; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_unit_institution ON codes.unit USING btree (institution_code);


--
-- TOC entry 3635 (class 1259 OID 17706)
-- Name: idx_unit_type; Type: INDEX; Schema: codes; Owner: -
--

CREATE INDEX idx_unit_type ON codes.unit USING btree (unit_type);


--
-- TOC entry 3554 (class 1259 OID 16856)
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- TOC entry 3557 (class 1259 OID 16857)
-- Name: idx_academic_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_academic_enrollment ON users.academic USING btree (enrollment_id);


--
-- TOC entry 3562 (class 1259 OID 16858)
-- Name: idx_application_academic_year; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_academic_year ON users.application USING btree (academic_year);


--
-- TOC entry 3563 (class 1259 OID 16859)
-- Name: idx_application_branch; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_branch ON users.application USING btree (branch_code);


--
-- TOC entry 3564 (class 1259 OID 16860)
-- Name: idx_application_codes; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_codes ON users.application USING btree (state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3565 (class 1259 OID 16861)
-- Name: idx_application_draft_expiry; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_draft_expiry ON users.application USING btree (application_status, draft_expires_time, expiry_processed) WHERE (application_status = 'draft'::text);


--
-- TOC entry 3566 (class 1259 OID 16862)
-- Name: idx_application_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_enrollment ON users.application USING btree (enrollment_id) WHERE (enrollment_id IS NOT NULL);


--
-- TOC entry 3567 (class 1259 OID 16863)
-- Name: idx_application_status; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_application_status ON users.application USING btree (application_status);


--
-- TOC entry 3570 (class 1259 OID 16864)
-- Name: idx_document_enrollment_id; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_enrollment_id ON users.document USING btree (enrollment_id);


--
-- TOC entry 3573 (class 1259 OID 16865)
-- Name: idx_document_verification_admin_id; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_admin_id ON users.document_verification USING btree (admin_id);


--
-- TOC entry 3574 (class 1259 OID 16866)
-- Name: idx_document_verification_document_type; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_document_type ON users.document_verification USING btree (document_type);


--
-- TOC entry 3575 (class 1259 OID 16867)
-- Name: idx_document_verification_enrollment_id; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_enrollment_id ON users.document_verification USING btree (enrollment_id);


--
-- TOC entry 3576 (class 1259 OID 16868)
-- Name: idx_document_verification_status; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_status ON users.document_verification USING btree (status);


--
-- TOC entry 3577 (class 1259 OID 16869)
-- Name: idx_document_verification_verified_at; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_verified_at ON users.document_verification USING btree (verified_time);


--
-- TOC entry 3578 (class 1259 OID 16870)
-- Name: idx_document_verification_verified_time; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_document_verification_verified_time ON users.document_verification USING btree (verified_time);


--
-- TOC entry 3579 (class 1259 OID 16871)
-- Name: idx_parent_contact; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_parent_contact ON users.parent USING btree (contact_number);


--
-- TOC entry 3580 (class 1259 OID 16872)
-- Name: idx_parent_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_parent_enrollment ON users.parent USING btree (enrollment_id);


--
-- TOC entry 3581 (class 1259 OID 16873)
-- Name: idx_parent_type; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_parent_type ON users.parent USING btree (parent_type);


--
-- TOC entry 3584 (class 1259 OID 16874)
-- Name: idx_sibling_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sibling_enrollment ON users.sibling USING btree (enrollment_id);


--
-- TOC entry 3587 (class 1259 OID 16875)
-- Name: idx_skill_geographic_hierarchy; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skill_geographic_hierarchy ON users.skill USING btree (state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3588 (class 1259 OID 16876)
-- Name: idx_skill_state_district; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skill_state_district ON users.skill USING btree (state_code, district_code);


--
-- TOC entry 3589 (class 1259 OID 16877)
-- Name: idx_skills_active; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skills_active ON users.skill USING btree (is_active);


--
-- TOC entry 3590 (class 1259 OID 16878)
-- Name: idx_skills_branch; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skills_branch ON users.skill USING btree (branch_code);


--
-- TOC entry 3591 (class 1259 OID 16879)
-- Name: idx_skills_category; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skills_category ON users.skill USING btree (skill_category);


--
-- TOC entry 3592 (class 1259 OID 16880)
-- Name: idx_skills_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skills_enrollment ON users.skill USING btree (enrollment_id);


--
-- TOC entry 3593 (class 1259 OID 16881)
-- Name: idx_skills_proficiency; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_skills_proficiency ON users.skill USING btree (proficiency_level);


--
-- TOC entry 3596 (class 1259 OID 16882)
-- Name: idx_sport_geographic_hierarchy; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sport_geographic_hierarchy ON users.sport USING btree (state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3597 (class 1259 OID 16883)
-- Name: idx_sport_state_district; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sport_state_district ON users.sport USING btree (state_code, district_code);


--
-- TOC entry 3598 (class 1259 OID 16884)
-- Name: idx_sports_active; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sports_active ON users.sport USING btree (is_active);


--
-- TOC entry 3599 (class 1259 OID 16885)
-- Name: idx_sports_branch; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sports_branch ON users.sport USING btree (branch_code);


--
-- TOC entry 3600 (class 1259 OID 16886)
-- Name: idx_sports_category; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sports_category ON users.sport USING btree (sport_category);


--
-- TOC entry 3601 (class 1259 OID 16887)
-- Name: idx_sports_enrollment; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sports_enrollment ON users.sport USING btree (enrollment_id);


--
-- TOC entry 3602 (class 1259 OID 16888)
-- Name: idx_sports_skill_level; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_sports_skill_level ON users.sport USING btree (skill_level);


--
-- TOC entry 3605 (class 1259 OID 16889)
-- Name: idx_student_academic_year; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_academic_year ON users.student USING btree (academic_year);


--
-- TOC entry 3606 (class 1259 OID 16890)
-- Name: idx_student_branch; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_branch ON users.student USING btree (branch_code);


--
-- TOC entry 3607 (class 1259 OID 16891)
-- Name: idx_student_communication_city; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_communication_city ON users.student USING btree (communication_city);


--
-- TOC entry 3608 (class 1259 OID 16892)
-- Name: idx_student_communication_district; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_communication_district ON users.student USING btree (communication_district);


--
-- TOC entry 3609 (class 1259 OID 16893)
-- Name: idx_student_communication_location; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_communication_location ON users.student USING btree (communication_city, communication_district);


--
-- TOC entry 3610 (class 1259 OID 16894)
-- Name: idx_student_communication_pincode; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_communication_pincode ON users.student USING btree (communication_pincode);


--
-- TOC entry 3611 (class 1259 OID 16895)
-- Name: idx_student_contact; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_contact ON users.student USING btree (primary_mobile);


--
-- TOC entry 3612 (class 1259 OID 16896)
-- Name: idx_student_email; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_email ON users.student USING btree (email);


--
-- TOC entry 3613 (class 1259 OID 16897)
-- Name: idx_student_emis_no; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_emis_no ON users.student USING btree (emis_no) WHERE (emis_no IS NOT NULL);


--
-- TOC entry 3614 (class 1259 OID 16898)
-- Name: idx_student_geographic_hierarchy; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_geographic_hierarchy ON users.student USING btree (state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3615 (class 1259 OID 16899)
-- Name: idx_student_name; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_name ON users.student USING btree (first_name, surname);


--
-- TOC entry 3616 (class 1259 OID 16900)
-- Name: idx_student_roll; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_roll ON users.student USING btree (roll_no, branch_code, academic_year);


--
-- TOC entry 3617 (class 1259 OID 16901)
-- Name: idx_student_state_district; Type: INDEX; Schema: users; Owner: -
--

CREATE INDEX idx_student_state_district ON users.student USING btree (state_code, district_code);


--
-- TOC entry 3675 (class 2620 OID 17736)
-- Name: branch_institution_unit branch_institution_unit_updated_time_trigger; Type: TRIGGER; Schema: codes; Owner: -
--

CREATE TRIGGER branch_institution_unit_updated_time_trigger BEFORE UPDATE ON codes.branch_institution_unit FOR EACH ROW EXECUTE FUNCTION public.update_branch_institution_unit_updated_time();


--
-- TOC entry 3674 (class 2620 OID 17709)
-- Name: unit unit_updated_time_trigger; Type: TRIGGER; Schema: codes; Owner: -
--

CREATE TRIGGER unit_updated_time_trigger BEFORE UPDATE ON codes.unit FOR EACH ROW EXECUTE FUNCTION public.update_unit_updated_time();


--
-- TOC entry 3650 (class 2606 OID 16956)
-- Name: branch_institution branch_institution_branch_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution
    ADD CONSTRAINT branch_institution_branch_fkey FOREIGN KEY (state_code, district_code, branch_code) REFERENCES codes.branch(state_code, district_code, branch_code);


--
-- TOC entry 3651 (class 2606 OID 16961)
-- Name: branch_institution branch_institution_institution_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution
    ADD CONSTRAINT branch_institution_institution_fkey FOREIGN KEY (institution_code) REFERENCES codes.institution(institution_code);


--
-- TOC entry 3672 (class 2606 OID 17721)
-- Name: branch_institution_unit branch_institution_unit_branch_institution_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution_unit
    ADD CONSTRAINT branch_institution_unit_branch_institution_fkey FOREIGN KEY (state_code, district_code, branch_code, institution_code) REFERENCES codes.branch_institution(state_code, district_code, branch_code, institution_code);


--
-- TOC entry 3673 (class 2606 OID 17726)
-- Name: branch_institution_unit branch_institution_unit_unit_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch_institution_unit
    ADD CONSTRAINT branch_institution_unit_unit_fkey FOREIGN KEY (institution_code, unit_code) REFERENCES codes.unit(institution_code, unit_code);


--
-- TOC entry 3649 (class 2606 OID 16966)
-- Name: branch branch_state_code_district_code_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.branch
    ADD CONSTRAINT branch_state_code_district_code_fkey FOREIGN KEY (state_code, district_code) REFERENCES codes.geographic(state_code, district_code);


--
-- TOC entry 3652 (class 2606 OID 16971)
-- Name: curriculum curriculum_institution_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.curriculum
    ADD CONSTRAINT curriculum_institution_fkey FOREIGN KEY (institution_code) REFERENCES codes.institution(institution_code);


--
-- TOC entry 3671 (class 2606 OID 17698)
-- Name: unit unit_institution_fkey; Type: FK CONSTRAINT; Schema: codes; Owner: -
--

ALTER TABLE ONLY codes.unit
    ADD CONSTRAINT unit_institution_fkey FOREIGN KEY (institution_code) REFERENCES codes.institution(institution_code);


--
-- TOC entry 3653 (class 2606 OID 16976)
-- Name: academic academic_curriculum_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.academic
    ADD CONSTRAINT academic_curriculum_fkey FOREIGN KEY (institution_code, program_code, department_code) REFERENCES codes.curriculum(institution_code, program_code, department_code);


--
-- TOC entry 3654 (class 2606 OID 16981)
-- Name: academic academic_student_enrollment_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.academic
    ADD CONSTRAINT academic_student_enrollment_fkey FOREIGN KEY (enrollment_id) REFERENCES users.student(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3655 (class 2606 OID 16986)
-- Name: application application_branch_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.application
    ADD CONSTRAINT application_branch_fkey FOREIGN KEY (state_code, district_code, branch_code) REFERENCES codes.branch(state_code, district_code, branch_code);


--
-- TOC entry 3656 (class 2606 OID 16991)
-- Name: application application_institution_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.application
    ADD CONSTRAINT application_institution_fkey FOREIGN KEY (institution_code) REFERENCES codes.institution(institution_code);


--
-- TOC entry 3657 (class 2606 OID 16996)
-- Name: application application_state_code_district_code_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.application
    ADD CONSTRAINT application_state_code_district_code_fkey FOREIGN KEY (state_code, district_code) REFERENCES codes.geographic(state_code, district_code);


--
-- TOC entry 3658 (class 2606 OID 17001)
-- Name: document fk_document_enrollment_id; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.document
    ADD CONSTRAINT fk_document_enrollment_id FOREIGN KEY (enrollment_id) REFERENCES users.student(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3661 (class 2606 OID 17006)
-- Name: skill fk_skill_geographic; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.skill
    ADD CONSTRAINT fk_skill_geographic FOREIGN KEY (state_code, district_code) REFERENCES codes.geographic(state_code, district_code);


--
-- TOC entry 3664 (class 2606 OID 17011)
-- Name: sport fk_sport_geographic; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sport
    ADD CONSTRAINT fk_sport_geographic FOREIGN KEY (state_code, district_code) REFERENCES codes.geographic(state_code, district_code);


--
-- TOC entry 3667 (class 2606 OID 17016)
-- Name: student fk_student_geographic; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT fk_student_geographic FOREIGN KEY (state_code, district_code) REFERENCES codes.geographic(state_code, district_code);


--
-- TOC entry 3659 (class 2606 OID 17021)
-- Name: parent parent_student_enrollment_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.parent
    ADD CONSTRAINT parent_student_enrollment_fkey FOREIGN KEY (enrollment_id) REFERENCES users.student(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3660 (class 2606 OID 17026)
-- Name: sibling sibling_student_enrollment_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sibling
    ADD CONSTRAINT sibling_student_enrollment_fkey FOREIGN KEY (enrollment_id) REFERENCES users.student(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3662 (class 2606 OID 17031)
-- Name: skill skills_branch_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.skill
    ADD CONSTRAINT skills_branch_fkey FOREIGN KEY (state_code, district_code, branch_code) REFERENCES codes.branch(state_code, district_code, branch_code);


--
-- TOC entry 3663 (class 2606 OID 17036)
-- Name: skill skills_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.skill
    ADD CONSTRAINT skills_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES users.application(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3665 (class 2606 OID 17041)
-- Name: sport sports_branch_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sport
    ADD CONSTRAINT sports_branch_fkey FOREIGN KEY (state_code, district_code, branch_code) REFERENCES codes.branch(state_code, district_code, branch_code);


--
-- TOC entry 3666 (class 2606 OID 17046)
-- Name: sport sports_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.sport
    ADD CONSTRAINT sports_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES users.application(enrollment_id) ON DELETE CASCADE;


--
-- TOC entry 3668 (class 2606 OID 17051)
-- Name: student student_branch_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_branch_fkey FOREIGN KEY (state_code, district_code, branch_code) REFERENCES codes.branch(state_code, district_code, branch_code);


--
-- TOC entry 3669 (class 2606 OID 17056)
-- Name: student student_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES users.application(enrollment_id);


--
-- TOC entry 3670 (class 2606 OID 17061)
-- Name: student student_institution_fkey; Type: FK CONSTRAINT; Schema: users; Owner: -
--

ALTER TABLE ONLY users.student
    ADD CONSTRAINT student_institution_fkey FOREIGN KEY (institution_code) REFERENCES codes.institution(institution_code);


-- Completed on 2025-08-20 13:19:44 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict Bj2dfF840QjpjcMZf7061JoRPbOC6pULwnHAIyHXkjzXDCdBElo94ivCqtphO5G

