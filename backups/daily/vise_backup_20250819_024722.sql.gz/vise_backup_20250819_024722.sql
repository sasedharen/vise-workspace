--
-- PostgreSQL database dump
--

\restrict 2rdavKH5le648VvGBVo57M7E17TS0J3Gg51C7W2HClQOcuzeltvYvlrBUC3q4Uw

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

-- Started on 2025-08-19 02:47:22 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 4 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- TOC entry 3402 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


-- Completed on 2025-08-19 02:47:22 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict 2rdavKH5le648VvGBVo57M7E17TS0J3Gg51C7W2HClQOcuzeltvYvlrBUC3q4Uw

